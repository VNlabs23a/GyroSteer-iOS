import android.hardware.SensorManager

fun main() {}
