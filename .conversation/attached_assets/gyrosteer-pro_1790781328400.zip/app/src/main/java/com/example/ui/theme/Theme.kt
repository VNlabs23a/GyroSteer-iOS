package com.example.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density

fun getExpressiveColorScheme(preset: String): ColorScheme {
    val primaryColor = when (preset) {
        "SPEED_BLUE" -> M3ExpressivePrimaryBlue
        "RACING_RED" -> M3ExpressivePrimaryRed
        "AMBER_GOLD" -> M3ExpressivePrimaryAmber
        "EMERALD_GREEN" -> M3ExpressivePrimaryGreen
        "PURPLE_EXPRESSIVE" -> M3ExpressivePrimaryPurple
        "MONOCHROME" -> M3ExpressivePrimaryMonochrome
        else -> M3ExpressivePrimaryBlue // Default M3 Expressive Blue
    }

    val secondaryColor = when (preset) {
        "SPEED_BLUE" -> M3ExpressiveSecondaryBlue
        "RACING_RED" -> M3ExpressiveSecondaryRed
        "AMBER_GOLD" -> M3ExpressiveSecondaryAmber
        "EMERALD_GREEN" -> M3ExpressiveSecondaryGreen
        "PURPLE_EXPRESSIVE" -> M3ExpressiveSecondaryPurple
        "MONOCHROME" -> M3ExpressiveSecondaryMonochrome
        else -> M3ExpressiveSecondaryBlue
    }

    return darkColorScheme(
        primary = primaryColor,
        onPrimary = if (preset == "MONOCHROME") Color.Black else Color.White,
        primaryContainer = CockpitSurfaceVariant,
        onPrimaryContainer = secondaryColor,
        secondary = secondaryColor,
        onSecondary = Color.White,
        tertiary = M3ExpressivePrimaryAmber,
        onTertiary = Color.Black,
        background = CockpitBackground,
        onBackground = Color.White,
        surface = CockpitSurface,
        onSurface = Color.White,
        surfaceVariant = CockpitSurfaceVariant,
        onSurfaceVariant = Color(0xFFCBD5E1),
        outline = CockpitBorder
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    themePreset: String = "MATERIAL_EXPRESSIVE",
    uiScaleDpi: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val colorScheme = getExpressiveColorScheme(themePreset)

    val currentDensity = LocalDensity.current
    val customDensity = Density(
        density = currentDensity.density * uiScaleDpi.coerceIn(0.7f, 1.5f),
        fontScale = currentDensity.fontScale * uiScaleDpi.coerceIn(0.7f, 1.5f)
    )

    CompositionLocalProvider(LocalDensity provides customDensity) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

