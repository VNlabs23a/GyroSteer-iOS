package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.network.TelemetryData
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CockpitSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.RacingRed
import com.example.ui.theme.ShiftBlue
import com.example.ui.theme.ShiftGreen
import com.example.ui.theme.ShiftRed
import com.example.ui.theme.ShiftYellow

@Composable
fun VirtualDashboardView(
    telemetry: TelemetryData,
    wheelAngleDegrees: Float,
    maxAngleDegrees: Float,
    isConnected: Boolean,
    leftBlinker: Boolean = false,
    rightBlinker: Boolean = false,
    onSimulateShiftUp: () -> Unit,
    onSimulateShiftDown: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activePrimary = MaterialTheme.colorScheme.primary

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CockpitSurface)
            .border(2.dp, activePrimary.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Rev Light Shift Strip (LEDs)
            val maxRpm = if (telemetry.maxRpm > 0) telemetry.maxRpm else 8000
            val rpmRatio = (telemetry.rpm.toFloat() / maxRpm).coerceIn(0f, 1f)
            val totalLeds = 10
            val activeLeds = (rpmRatio * totalLeds).toInt()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until totalLeds) {
                    val isActive = i < activeLeds
                    val ledColor = when {
                        !isActive -> Color.DarkGray
                        i < 4 -> ShiftGreen
                        i < 7 -> ShiftYellow
                        i < 9 -> ShiftRed
                        else -> ShiftBlue
                    }
                    val animatedColor by animateColorAsState(targetValue = ledColor, label = "led")

                    Box(
                        modifier = Modifier
                            .size(width = 16.dp, height = 8.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(animatedColor)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Main Telemetry Hub (Gear & Speed)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Blinker Arrow
                val leftBlinkColor by animateColorAsState(targetValue = if (leftBlinker && (System.currentTimeMillis() % 600 > 300)) ShiftGreen else Color.DarkGray)
                Text(
                    text = "◀",
                    fontSize = 20.sp,
                    color = leftBlinkColor
                )

                // Left: Speedometer
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${telemetry.speedKmh}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )
                    Text(
                        text = "KM/H",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = activePrimary
                    )
                }

                // Center: Big Gear Indicator
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color.Black)
                        .border(2.dp, RacingRed, CircleShape)
                        .clickable { onSimulateShiftUp() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = telemetry.gear,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = RacingRed
                    )
                }

                // Right: RPM Counter
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${telemetry.rpm}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )
                    Text(
                        text = "RPM",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberGold
                    )
                }

                // Right Blinker Arrow
                val rightBlinkColor by animateColorAsState(targetValue = if (rightBlinker && (System.currentTimeMillis() % 600 > 300)) ShiftGreen else Color.DarkGray)
                Text(
                    text = "▶",
                    fontSize = 20.sp,
                    color = rightBlinkColor
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Bottom Badges & Real-time Degree Readout
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Telemetry Badges
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    BadgeChip(text = "TC", active = telemetry.tcActive, activeColor = AmberGold)
                    BadgeChip(text = "ABS", active = telemetry.absActive, activeColor = ShiftRed)
                    BadgeChip(text = "DRS", active = telemetry.drsAvailable, activeColor = ShiftGreen)
                }

                // Angle degree counter
                val angleText = String.format("%+.1f°", wheelAngleDegrees)
                Text(
                    text = "$angleText / ${maxAngleDegrees.toInt()}°",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = activePrimary
                )
            }
        }
    }
}

@Composable
private fun BadgeChip(text: String, active: Boolean, activeColor: Color) {
    val bg = if (active) activeColor else Color.DarkGray.copy(alpha = 0.5f)
    val fg = if (active) Color.Black else Color.Gray

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = fg
        )
    }
}
