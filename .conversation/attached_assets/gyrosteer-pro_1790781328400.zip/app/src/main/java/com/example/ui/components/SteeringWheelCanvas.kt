package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material3.MaterialTheme
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.CarbonLight
import com.example.ui.theme.RacingRed

@Composable
fun SteeringWheelCanvas(
    angleDegrees: Float,
    isNearLock: Boolean,
    colorHex: String = "",
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit = {}
) {
    val activePrimary = MaterialTheme.colorScheme.primary
    val customColor = remember(colorHex) {
        if (colorHex.isNotBlank()) {
            try {
                Color(android.graphics.Color.parseColor(if (colorHex.startsWith("#")) colorHex else "#$colorHex"))
            } catch (e: Exception) {
                null
            }
        } else null
    }
    val baseColor = customColor ?: activePrimary
    val rimLockColor = if (isNearLock) RacingRed else baseColor

    Box(
        modifier = modifier
            .graphicsLayer {
                rotationZ = angleDegrees
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val outerRadius = (minOf(size.width, size.height) / 2f) * 0.92f
            val rimThickness = outerRadius * 0.16f
            val innerRadius = outerRadius - rimThickness

            // Outer Leather Rim
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(CarbonLight, CarbonDark, Color.Black),
                    center = center,
                    radius = outerRadius
                ),
                radius = outerRadius,
                center = center
            )

            // Inner Hollow Cutout
            drawCircle(
                color = Color.Black,
                radius = innerRadius,
                center = center
            )

            // Rim Edge Accent Ring
            drawCircle(
                color = rimLockColor,
                radius = outerRadius,
                center = center,
                style = Stroke(width = 4f)
            )

            // Top Center Alignment Stripe (12 o'clock red stripe on racing wheel)
            val stripeWidth = 24f
            val stripeHeight = rimThickness * 1.1f
            drawRect(
                color = RacingRed,
                topLeft = Offset(center.x - stripeWidth / 2f, center.y - outerRadius),
                size = Size(stripeWidth, stripeHeight)
            )

            // Carbon Spokes (3-Spoke GT Wheel)
            val spokeWidth = rimThickness * 0.9f
            
            // Left Spoke (9 o'clock)
            drawPath(
                path = Path().apply {
                    moveTo(center.x - innerRadius, center.y - spokeWidth / 2f)
                    lineTo(center.x - innerRadius * 0.4f, center.y - spokeWidth * 0.3f)
                    lineTo(center.x - innerRadius * 0.4f, center.y + spokeWidth * 0.3f)
                    lineTo(center.x - innerRadius, center.y + spokeWidth / 2f)
                    close()
                },
                brush = Brush.horizontalGradient(listOf(CarbonDark, CarbonLight))
            )

            // Right Spoke (3 o'clock)
            drawPath(
                path = Path().apply {
                    moveTo(center.x + innerRadius, center.y - spokeWidth / 2f)
                    lineTo(center.x + innerRadius * 0.4f, center.y - spokeWidth * 0.3f)
                    lineTo(center.x + innerRadius * 0.4f, center.y + spokeWidth * 0.3f)
                    lineTo(center.x + innerRadius, center.y + spokeWidth / 2f)
                    close()
                },
                brush = Brush.horizontalGradient(listOf(CarbonLight, CarbonDark))
            )

            // Bottom Spoke (6 o'clock)
            drawPath(
                path = Path().apply {
                    moveTo(center.x - spokeWidth / 2f, center.y + innerRadius)
                    lineTo(center.x - spokeWidth * 0.3f, center.y + innerRadius * 0.4f)
                    lineTo(center.x + spokeWidth * 0.3f, center.y + innerRadius * 0.4f)
                    lineTo(center.x + spokeWidth / 2f, center.y + innerRadius)
                    close()
                },
                brush = Brush.verticalGradient(listOf(CarbonLight, CarbonDark))
            )

            // Center Steering Wheel Hub
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF2B313A), Color(0xFF14171D)),
                    center = center,
                    radius = innerRadius * 0.5f
                ),
                radius = innerRadius * 0.5f,
                center = center
            )

            drawCircle(
                color = Color(0xFF383E4A),
                radius = innerRadius * 0.5f,
                center = center,
                style = Stroke(width = 3f)
            )
        }

        // Center display overlay slot
        content()
    }
}
