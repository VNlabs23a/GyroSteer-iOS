package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ButtonMappingEntity
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CockpitBackground
import com.example.ui.theme.CockpitSurface
import com.example.ui.theme.CockpitSurfaceVariant
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.RacingRed

@Composable
fun ButtonMappingEditorDialog(
    buttonMappings: List<ButtonMappingEntity>,
    onDismiss: () -> Unit,
    onSaveButton: (ButtonMappingEntity) -> Unit,
    onDeleteButton: (Int) -> Unit,
    onLoadBusLayout: () -> Unit = {},
    onLoadDefaultLayout: () -> Unit = {}
) {
    var newLabel by remember { mutableStateOf("NITRO") }
    var newActionCode by remember { mutableStateOf("NITRO") }
    var xRatio by remember { mutableStateOf(0.5f) }
    var yRatio by remember { mutableStateOf(0.8f) }
    var sizeScale by remember { mutableStateOf(1.0f) }
    var colorHex by remember { mutableStateOf("") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.88f)
                .clip(RoundedCornerShape(20.dp))
                .background(CockpitBackground)
                .border(2.dp, AmberGold, RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Edit, contentDescription = null, tint = AmberGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Custom Button Mapping Editor",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onLoadDefaultLayout,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = CockpitSurfaceVariant, contentColor = Color.White)
                    ) {
                        Text("Default Layout", fontSize = 12.sp)
                    }
                    Button(
                        onClick = onLoadBusLayout,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = CockpitSurfaceVariant, contentColor = Color.White)
                    ) {
                        Text("Bus Preset Layout", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Button List
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Current Mapped Wheel Controls", fontWeight = FontWeight.Bold, color = AmberGold)

                    buttonMappings.forEach { btn ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CockpitSurface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(btn.label, fontWeight = FontWeight.Bold, color = Color.White)
                                    Text("Action: ${btn.actionCode} | Pos: (${(btn.xRatio * 100).toInt()}%, ${(btn.yRatio * 100).toInt()}%)", fontSize = 11.sp, color = Color.Gray)
                                }
                                IconButton(onClick = { onDeleteButton(btn.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = RacingRed)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Add New Custom Control Button", fontWeight = FontWeight.Bold, color = NeonCyan)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = newLabel,
                            onValueChange = { newLabel = it },
                            label = { Text("Label") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan)
                        )
                        OutlinedTextField(
                            value = newActionCode,
                            onValueChange = { newActionCode = it },
                            label = { Text("Action Code") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan)
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = xRatio.toString(),
                            onValueChange = { xRatio = it.toFloatOrNull() ?: 0f },
                            label = { Text("X Ratio (0-1)") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan)
                        )
                        OutlinedTextField(
                            value = yRatio.toString(),
                            onValueChange = { yRatio = it.toFloatOrNull() ?: 0f },
                            label = { Text("Y Ratio (0-1)") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan)
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = sizeScale.toString(),
                            onValueChange = { sizeScale = it.toFloatOrNull() ?: 1f },
                            label = { Text("Size Scale") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan)
                        )
                        OutlinedTextField(
                            value = colorHex,
                            onValueChange = { colorHex = it },
                            label = { Text("Color Hex") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan)
                        )
                    }

                    Button(
                        onClick = {
                            if (newLabel.isNotBlank()) {
                                onSaveButton(
                                    ButtonMappingEntity(
                                        buttonId = "btn_${System.currentTimeMillis()}",
                                        label = newLabel,
                                        xRatio = xRatio,
                                        yRatio = yRatio,
                                        actionCode = newActionCode,
                                        sizeScale = sizeScale,
                                        colorHex = colorHex
                                    )
                                )
                                newLabel = ""
                                newActionCode = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = Color.Black)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Add Button to Wheel", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
