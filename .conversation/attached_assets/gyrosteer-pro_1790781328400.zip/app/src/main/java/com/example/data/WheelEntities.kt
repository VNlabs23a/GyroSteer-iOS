package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wheel_configs")
data class WheelConfigEntity(
    @PrimaryKey val id: Int = 1,
    val maxAngleDegrees: Float = 900f,
    val deadzonePercentage: Float = 2.0f,
    val steeringLinearity: Float = 1.2f, // 1.0 = linear, >1 = more precise center
    val hapticLockEnabled: Boolean = true,
    val hapticIntensity: Float = 0.8f,
    val hapticLockMarginDegrees: Float = 25f, // degrees before max lock to start pulsing
    val smoothingFactor: Float = 0.15f, // low pass filter weight (0 = raw, 0.5 = heavy)
    val pcIpAddress: String = "192.168.1.100",
    val udpPort: Int = 8080,
    val sendFrequencyHz: Int = 60,
    val protocolMode: String = "BINARY", // "BINARY" or "JSON"
    val connectionMode: String = "USB_UDP", // "USB_UDP", "WIFI_UDP", "BLUETOOTH"
    val isTelemetryEnabled: Boolean = true,
    val activeProfileName: String = "900° Standard",
    val rattleFilter: Float = 0.05f, // Gyro jitter noise suppressor threshold
    val autoRecenterEnabled: Boolean = false, // Auto-recenter zero drift when steady near center
    val allowUpsideDownLandscape: Boolean = false, // Allow 180° flip (Sensor Landscape vs Fixed Landscape)
    val uiScaleDpi: Float = 1.0f, // 0.75x to 1.50x DPI scale factor
    val themePreset: String = "MATERIAL_EXPRESSIVE", // "MATERIAL_EXPRESSIVE", "SPEED_BLUE", "RACING_RED", "EMERALD_GREEN", "PURPLE_EXPRESSIVE", "MONOCHROME"
    val isExpressiveShapes: Boolean = true,
    val disableNeonGlow: Boolean = true, // Material 3 Flat Expressive Colors, NO NEON!

    // Custom UI Overrides
    val wheelSizeDp: Float = 280f,
    val wheelColorHex: String = "", // empty means theme default
    val wheelXOffsetDp: Float = 0f,
    val wheelYOffsetDp: Float = 0f,
    val paddleSizeScale: Float = 1.0f,
    val paddleColorHex: String = "", // empty means theme default
    val paddleXOffsetDp: Float = 0f,
    val paddleYOffsetDp: Float = 0f
)

@Entity(tableName = "button_mappings")
data class ButtonMappingEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val buttonId: String,
    val label: String,
    val xRatio: Float, // 0.0 to 1.0 screen relative
    val yRatio: Float, // 0.0 to 1.0 screen relative
    val actionCode: String, // e.g., "SHIFT_UP", "SHIFT_DOWN", "NITRO", "HANDBRAKE", "DRS", "HORN", "TC_PLUS", "TC_MINUS", "ABS_PLUS", "ABS_MINUS", "PIT", "PAUSE"
    val isPaddle: Boolean = false,
    val isToggle: Boolean = false,
    val hapticOnPress: Boolean = true,
    val sizeScale: Float = 1.0f,
    val colorHex: String = "" // empty means theme default
)

@Entity(tableName = "wheel_profiles")
data class WheelProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val maxAngleDegrees: Float,
    val linearity: Float,
    val deadzone: Float,
    val description: String
)
