package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Phonelink
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.WheelConfigEntity
import com.example.data.WheelProfileEntity
import com.example.network.ExternalGamepadState
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CockpitBackground
import com.example.ui.theme.CockpitBorder
import com.example.ui.theme.CockpitSurface
import com.example.ui.theme.CockpitSurfaceVariant
import com.example.ui.theme.M3ExpressivePrimaryAmber
import com.example.ui.theme.M3ExpressivePrimaryBlue
import com.example.ui.theme.M3ExpressivePrimaryGreen
import com.example.ui.theme.M3ExpressivePrimaryMonochrome
import com.example.ui.theme.M3ExpressivePrimaryPurple
import com.example.ui.theme.M3ExpressivePrimaryRed
import com.example.ui.theme.M3ExpressiveSecondaryAmber
import com.example.ui.theme.M3ExpressiveSecondaryBlue
import com.example.ui.theme.M3ExpressiveSecondaryGreen
import com.example.ui.theme.M3ExpressiveSecondaryMonochrome
import com.example.ui.theme.M3ExpressiveSecondaryPurple
import com.example.ui.theme.M3ExpressiveSecondaryRed
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.RacingRed

@Composable
fun SettingsAndCalibrationDialog(
    config: WheelConfigEntity,
    profiles: List<WheelProfileEntity>,
    externalGamepad: ExternalGamepadState,
    onDismiss: () -> Unit,
    onSaveConfig: (WheelConfigEntity) -> Unit,
    onRecenter: () -> Unit,
    onCalibrateZero: () -> Unit,
    onApplyProfile: (WheelProfileEntity) -> Unit,
    onOpenPcScript: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    // Draft Config State
    var maxAngle by remember { mutableStateOf(config.maxAngleDegrees) }
    var deadzone by remember { mutableStateOf(config.deadzonePercentage) }
    var linearity by remember { mutableStateOf(config.steeringLinearity) }
    var smoothing by remember { mutableStateOf(config.smoothingFactor) }
    var rattleFilter by remember { mutableStateOf(config.rattleFilter) }
    var autoRecenter by remember { mutableStateOf(config.autoRecenterEnabled) }
    var allowUpsideDown by remember { mutableStateOf(config.allowUpsideDownLandscape) }

    var uiScaleDpi by remember { mutableFloatStateOf(config.uiScaleDpi) }
    var themePreset by remember { mutableStateOf(config.themePreset) }
    var isExpressiveShapes by remember { mutableStateOf(config.isExpressiveShapes) }
    var disableNeonGlow by remember { mutableStateOf(config.disableNeonGlow) }
    
    var wheelSizeDp by remember { mutableFloatStateOf(config.wheelSizeDp) }
    var wheelColorHex by remember { mutableStateOf(config.wheelColorHex) }
    var wheelXOffsetDp by remember { mutableFloatStateOf(config.wheelXOffsetDp) }
    var wheelYOffsetDp by remember { mutableFloatStateOf(config.wheelYOffsetDp) }
    
    var paddleSizeScale by remember { mutableFloatStateOf(config.paddleSizeScale) }
    var paddleColorHex by remember { mutableStateOf(config.paddleColorHex) }

    var hapticEnabled by remember { mutableStateOf(config.hapticLockEnabled) }
    var hapticIntensity by remember { mutableStateOf(config.hapticIntensity) }
    var hapticMargin by remember { mutableStateOf(config.hapticLockMarginDegrees) }

    var ipAddress by remember { mutableStateOf(config.pcIpAddress) }
    var udpPortStr by remember { mutableStateOf(config.udpPort.toString()) }
    var sendHz by remember { mutableStateOf(config.sendFrequencyHz) }
    var isBinary by remember { mutableStateOf(config.protocolMode == "BINARY") }

    val activePrimaryColor = MaterialTheme.colorScheme.primary

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(20.dp))
                .background(CockpitBackground)
                .border(2.dp, activePrimaryColor, RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = activePrimaryColor)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Wheel Calibration & Settings",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Tabs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = CockpitSurface,
                    contentColor = activePrimaryColor,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = activePrimaryColor
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Calibration", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Haptics", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Themes & UI", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = { Text("PC / Network", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 4,
                        onClick = { selectedTab = 4 },
                        text = { Text("USB OTG", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 5,
                        onClick = { selectedTab = 5 },
                        text = { Text("Profiles", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Tab Content Body
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    when (selectedTab) {
                        0 -> CalibrationTab(
                            maxAngle = maxAngle,
                            onMaxAngleChange = { maxAngle = it },
                            deadzone = deadzone,
                            onDeadzoneChange = { deadzone = it },
                            linearity = linearity,
                            onLinearityChange = { linearity = it },
                            smoothing = smoothing,
                            onSmoothingChange = { smoothing = it },
                            rattleFilter = rattleFilter,
                            onRattleFilterChange = { rattleFilter = it },
                            autoRecenter = autoRecenter,
                            onAutoRecenterChange = { autoRecenter = it },
                            allowUpsideDown = allowUpsideDown,
                            onAllowUpsideDownChange = { allowUpsideDown = it },
                            onRecenter = onRecenter,
                            onCalibrateZero = onCalibrateZero
                        )
                        1 -> HapticsTab(
                            hapticEnabled = hapticEnabled,
                            onHapticEnabledChange = { hapticEnabled = it },
                            intensity = hapticIntensity,
                            onIntensityChange = { hapticIntensity = it },
                            marginDegrees = hapticMargin,
                            onMarginChange = { hapticMargin = it }
                        )
                        2 -> ThemesTab(
                            uiScaleDpi = uiScaleDpi,
                            onUiScaleDpiChange = { uiScaleDpi = it },
                            themePreset = themePreset,
                            onThemePresetChange = { themePreset = it },
                            isExpressiveShapes = isExpressiveShapes,
                            onExpressiveShapesChange = { isExpressiveShapes = it },
                            disableNeonGlow = disableNeonGlow,
                            onDisableNeonGlowChange = { disableNeonGlow = it },
                            wheelSizeDp = wheelSizeDp,
                            onWheelSizeChange = { wheelSizeDp = it },
                            wheelColorHex = wheelColorHex,
                            onWheelColorChange = { wheelColorHex = it },
                            wheelXOffsetDp = wheelXOffsetDp,
                            onWheelXOffsetChange = { wheelXOffsetDp = it },
                            wheelYOffsetDp = wheelYOffsetDp,
                            onWheelYOffsetChange = { wheelYOffsetDp = it },
                            paddleSizeScale = paddleSizeScale,
                            onPaddleSizeChange = { paddleSizeScale = it },
                            paddleColorHex = paddleColorHex,
                            onPaddleColorChange = { paddleColorHex = it }
                        )
                        3 -> ConnectionTab(
                            ipAddress = ipAddress,
                            onIpChange = { ipAddress = it },
                            udpPortStr = udpPortStr,
                            onPortChange = { udpPortStr = it },
                            sendHz = sendHz,
                            onHzChange = { sendHz = it },
                            isBinary = isBinary,
                            onBinaryChange = { isBinary = it },
                            onOpenPcScript = onOpenPcScript
                        )
                        4 -> UsbOtgTab(externalGamepad = externalGamepad)
                        5 -> ProfilesTab(
                            profiles = profiles,
                            activeProfileName = config.activeProfileName,
                            onApplyProfile = onApplyProfile
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Save Footer Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = {
                            val port = udpPortStr.toIntOrNull() ?: 8080
                            onSaveConfig(
                                config.copy(
                                    maxAngleDegrees = maxAngle,
                                    deadzonePercentage = deadzone,
                                    steeringLinearity = linearity,
                                    smoothingFactor = smoothing,
                                    rattleFilter = rattleFilter,
                                    autoRecenterEnabled = autoRecenter,
                                    allowUpsideDownLandscape = allowUpsideDown,
                                    uiScaleDpi = uiScaleDpi,
                                    themePreset = themePreset,
                                    isExpressiveShapes = isExpressiveShapes,
                                    disableNeonGlow = disableNeonGlow,
                                    wheelSizeDp = wheelSizeDp,
                                    wheelColorHex = wheelColorHex,
                                    wheelXOffsetDp = wheelXOffsetDp,
                                    wheelYOffsetDp = wheelYOffsetDp,
                                    paddleSizeScale = paddleSizeScale,
                                    paddleColorHex = paddleColorHex,
                                    hapticLockEnabled = hapticEnabled,
                                    hapticIntensity = hapticIntensity,
                                    hapticLockMarginDegrees = hapticMargin,
                                    pcIpAddress = ipAddress,
                                    udpPort = port,
                                    sendFrequencyHz = sendHz,
                                    protocolMode = if (isBinary) "BINARY" else "JSON"
                                )
                            )
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = activePrimaryColor, contentColor = Color.Black)
                    ) {
                        Text("Apply & Save Settings", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun CalibrationTab(
    maxAngle: Float,
    onMaxAngleChange: (Float) -> Unit,
    deadzone: Float,
    onDeadzoneChange: (Float) -> Unit,
    linearity: Float,
    onLinearityChange: (Float) -> Unit,
    smoothing: Float,
    onSmoothingChange: (Float) -> Unit,
    rattleFilter: Float,
    onRattleFilterChange: (Float) -> Unit,
    autoRecenter: Boolean,
    onAutoRecenterChange: (Boolean) -> Unit,
    allowUpsideDown: Boolean,
    onAllowUpsideDownChange: (Boolean) -> Unit,
    onRecenter: () -> Unit,
    onCalibrateZero: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Quick Recenter Action Buttons
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = onRecenter,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = Color.Black)
            ) {
                Text("Recenter Wheel Now", fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onCalibrateZero,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = CockpitSurfaceVariant, contentColor = Color.White)
            ) {
                Text("Zero Gyro Drift", fontWeight = FontWeight.Bold)
            }
        }

        // Auto Gyro Recenter Switch
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CockpitSurface)
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Automatic Gyro Drift Recenter", fontWeight = FontWeight.Bold, color = Color.White)
                Text("Automatically centers zero-point when phone is held still near center", fontSize = 11.sp, color = Color.Gray)
            }
            Switch(
                checked = autoRecenter,
                onCheckedChange = onAutoRecenterChange,
                colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
            )
        }

        // Orientation Lock Switch
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CockpitSurface)
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Allow 180° Landscape Flip", fontWeight = FontWeight.Bold, color = Color.White)
                Text(if (allowUpsideDown) "Rotates with device (Sensor Landscape)" else "Locked in standard Landscape mode", fontSize = 11.sp, color = Color.Gray)
            }
            Switch(
                checked = allowUpsideDown,
                onCheckedChange = onAllowUpsideDownChange,
                colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
            )
        }

        // Max Angle Lock-to-Lock
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                SettingSliderItem(
                    title = "Max Steering Rotation Lock-to-Lock",
                    valueText = "${maxAngle.toInt()}° (${String.format("%.1f", maxAngle / 360f)} Turns)",
                    value = maxAngle.coerceIn(180f, 1800f),
                    valueRange = 180f..1800f,
                    steps = 17,
                    onValueChange = onMaxAngleChange
                )
            }
            OutlinedTextField(
                value = maxAngle.toInt().toString(),
                onValueChange = { 
                    val newAngle = it.toFloatOrNull()
                    if (newAngle != null) onMaxAngleChange(newAngle)
                },
                label = { Text("°") },
                modifier = Modifier.width(80.dp),
                singleLine = true
            )
        }

        // Linearity Curve
        SettingSliderItem(
            title = "Steering Linearity Curve",
            valueText = if (linearity == 1.0f) "1.0 (Linear 1:1)" else "${String.format("%.2f", linearity)} (Center Precision)",
            value = linearity,
            valueRange = 0.8f..2.0f,
            steps = 12,
            onValueChange = onLinearityChange
        )

        // Deadzone %
        SettingSliderItem(
            title = "Center Deadzone Threshold",
            valueText = "${String.format("%.1f", deadzone)}%",
            value = deadzone,
            valueRange = 0f..10f,
            steps = 20,
            onValueChange = onDeadzoneChange
        )

        // Rattle / Micro-Jitter Filter
        SettingSliderItem(
            title = "Deadzone Rattle & Jitter Filter",
            valueText = if (rattleFilter == 0f) "Off (Raw Gyro)" else "${String.format("%.3f", rattleFilter)} rad/s Suppressed",
            value = rattleFilter,
            valueRange = 0f..0.15f,
            steps = 15,
            onValueChange = onRattleFilterChange
        )

        // Smoothing Filter
        SettingSliderItem(
            title = "Gyro Low-Pass Smoothing",
            valueText = if (smoothing == 0f) "0% (Raw Instant)" else "${(smoothing * 100).toInt()}% Smooth",
            value = smoothing,
            valueRange = 0f..0.5f,
            steps = 10,
            onValueChange = onSmoothingChange
        )
    }
}

@Composable
private fun HapticsTab(
    hapticEnabled: Boolean,
    onHapticEnabledChange: (Boolean) -> Unit,
    intensity: Float,
    onIntensityChange: (Float) -> Unit,
    marginDegrees: Float,
    onMarginChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Lock Limit Vibrations", fontWeight = FontWeight.Bold, color = Color.White)
                Text("Increasing haptic feedback near wheel lock limit", fontSize = 12.sp, color = Color.Gray)
            }
            Switch(
                checked = hapticEnabled,
                onCheckedChange = onHapticEnabledChange,
                colors = SwitchDefaults.colors(checkedThumbColor = RacingRed)
            )
        }

        if (hapticEnabled) {
            SettingSliderItem(
                title = "Lock Vibration Intensity",
                valueText = "${(intensity * 100).toInt()}%",
                value = intensity,
                valueRange = 0.1f..1.0f,
                steps = 9,
                onValueChange = onIntensityChange
            )

            SettingSliderItem(
                title = "Lock Vibration Proximity Margin",
                valueText = "${marginDegrees.toInt()}° before max lock",
                value = marginDegrees,
                valueRange = 10f..50f,
                steps = 8,
                onValueChange = onMarginChange
            )
        }
    }
}

@Composable
private fun ConnectionTab(
    ipAddress: String,
    onIpChange: (String) -> Unit,
    udpPortStr: String,
    onPortChange: (String) -> Unit,
    sendHz: Int,
    onHzChange: (Int) -> Unit,
    isBinary: Boolean,
    onBinaryChange: (Boolean) -> Unit,
    onOpenPcScript: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = ipAddress,
                onValueChange = onIpChange,
                label = { Text("PC / Host IP Address") },
                modifier = Modifier.weight(2f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = CockpitSurfaceVariant,
                    focusedLabelColor = NeonCyan
                )
            )

            OutlinedTextField(
                value = udpPortStr,
                onValueChange = onPortChange,
                label = { Text("UDP Port") },
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = CockpitSurfaceVariant,
                    focusedLabelColor = NeonCyan
                )
            )
        }

        SettingSliderItem(
            title = "Transmission Frequency (Rate)",
            valueText = "$sendHz Hz (${1000 / sendHz}ms update interval)",
            value = sendHz.toFloat(),
            valueRange = 30f..120f,
            steps = 3,
            onValueChange = { onHzChange(it.toInt()) }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Compact Binary Protocol", fontWeight = FontWeight.Bold, color = Color.White)
                Text(if (isBinary) "Ultra-low latency 24-byte binary packet" else "Human-readable JSON packet", fontSize = 12.sp, color = Color.Gray)
            }
            Switch(
                checked = isBinary,
                onCheckedChange = onBinaryChange,
                colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
            )
        }

        Button(
            onClick = onOpenPcScript,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = CockpitSurfaceVariant, contentColor = NeonCyan)
        ) {
            Icon(Icons.Default.Code, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Generate PC Receiver Python Script (vJoy)", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun UsbOtgTab(externalGamepad: ExternalGamepadState) {
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("External Physical Wheel / Pedals via USB OTG", fontWeight = FontWeight.Bold, color = Color.White)
        Text("Connect an external USB game controller or pedal set to your phone via USB OTG adapter.", fontSize = 12.sp, color = Color.Gray)

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CockpitSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Status: ${externalGamepad.deviceName}", fontWeight = FontWeight.Bold, color = NeonCyan)
                Text("Accelerator Axis: ${(externalGamepad.pedalAccelerator * 100).toInt()}%", color = Color.White)
                Text("Brake Axis: ${(externalGamepad.pedalBrake * 100).toInt()}%", color = Color.White)
                Text("Buttons Pressed: ${externalGamepad.physicalButtonsPressed.joinToString(", ").ifEmpty { "None" }}", color = Color.Gray)
            }
        }
    }
}

@Composable
private fun ProfilesTab(
    profiles: List<WheelProfileEntity>,
    activeProfileName: String,
    onApplyProfile: (WheelProfileEntity) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Pre-configured Racing Profiles", fontWeight = FontWeight.Bold, color = Color.White)

        profiles.forEach { profile ->
            val isActive = profile.name == activeProfileName
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (isActive) NeonCyan else Color.Transparent,
                        RoundedCornerShape(12.dp)
                    ),
                colors = CardDefaults.cardColors(containerColor = CockpitSurface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(profile.name, fontWeight = FontWeight.Bold, color = if (isActive) NeonCyan else Color.White)
                        Text(profile.description, fontSize = 11.sp, color = Color.Gray)
                        Text("${profile.maxAngleDegrees.toInt()}° | Linearity: ${profile.linearity}", fontSize = 11.sp, color = AmberGold)
                    }

                    Button(
                        onClick = { onApplyProfile(profile) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isActive) NeonCyan else CockpitSurfaceVariant,
                            contentColor = if (isActive) Color.Black else Color.White
                        )
                    ) {
                        Text(if (isActive) "Active" else "Apply")
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemesTab(
    uiScaleDpi: Float,
    onUiScaleDpiChange: (Float) -> Unit,
    themePreset: String,
    onThemePresetChange: (String) -> Unit,
    isExpressiveShapes: Boolean,
    onExpressiveShapesChange: (Boolean) -> Unit,
    disableNeonGlow: Boolean,
    onDisableNeonGlowChange: (Boolean) -> Unit,
    wheelSizeDp: Float,
    onWheelSizeChange: (Float) -> Unit,
    wheelColorHex: String,
    onWheelColorChange: (String) -> Unit,
    wheelXOffsetDp: Float,
    onWheelXOffsetChange: (Float) -> Unit,
    wheelYOffsetDp: Float,
    onWheelYOffsetChange: (Float) -> Unit,
    paddleSizeScale: Float,
    onPaddleSizeChange: (Float) -> Unit,
    paddleColorHex: String,
    onPaddleColorChange: (String) -> Unit
) {
    val activeColor = MaterialTheme.colorScheme.primary

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Custom Component Overrides", fontWeight = FontWeight.Bold, color = NeonCyan)
        
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = wheelSizeDp.toString(),
                onValueChange = { onWheelSizeChange(it.toFloatOrNull() ?: 280f) },
                label = { Text("Wheel Size (dp)") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = wheelColorHex,
                onValueChange = onWheelColorChange,
                label = { Text("Wheel Color Hex") },
                modifier = Modifier.weight(1f)
            )
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = wheelXOffsetDp.toString(),
                onValueChange = { onWheelXOffsetChange(it.toFloatOrNull() ?: 0f) },
                label = { Text("Wheel X Offset") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = wheelYOffsetDp.toString(),
                onValueChange = { onWheelYOffsetChange(it.toFloatOrNull() ?: 0f) },
                label = { Text("Wheel Y Offset") },
                modifier = Modifier.weight(1f)
            )
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = paddleSizeScale.toString(),
                onValueChange = { onPaddleSizeChange(it.toFloatOrNull() ?: 1.0f) },
                label = { Text("Paddle Size Scale") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = paddleColorHex,
                onValueChange = onPaddleColorChange,
                label = { Text("Paddle Color Hex") },
                modifier = Modifier.weight(1f)
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Interface DPI & Layout Scale Multiplier",
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontSize = 15.sp
        )

        val dpiPercent = (uiScaleDpi * 100).toInt()
        val dpiLabel = when {
            dpiPercent < 90 -> "$dpiPercent% (Compact Mode)"
            dpiPercent in 90..110 -> "$dpiPercent% (Standard Mode)"
            else -> "$dpiPercent% (Enlarged Mode)"
        }

        SettingSliderItem(
            title = "DPI Scaling Multiplier",
            valueText = dpiLabel,
            value = uiScaleDpi,
            valueRange = 0.75f..1.50f,
            steps = 15,
            onValueChange = onUiScaleDpiChange
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Material 3 Expressive Color Palettes (NO NEON!)",
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontSize = 15.sp
        )

        val presets = listOf(
            Triple("MATERIAL_EXPRESSIVE", "M3 Expressive", Pair(M3ExpressivePrimaryBlue, M3ExpressiveSecondaryBlue)),
            Triple("SPEED_BLUE", "Speed Blue", Pair(M3ExpressivePrimaryBlue, M3ExpressiveSecondaryBlue)),
            Triple("RACING_RED", "Apex Crimson", Pair(M3ExpressivePrimaryRed, M3ExpressiveSecondaryRed)),
            Triple("EMERALD_GREEN", "Forest Emerald", Pair(M3ExpressivePrimaryGreen, M3ExpressiveSecondaryGreen)),
            Triple("AMBER_GOLD", "Amber Performance", Pair(M3ExpressivePrimaryAmber, M3ExpressiveSecondaryAmber)),
            Triple("PURPLE_EXPRESSIVE", "Violet Velocity", Pair(M3ExpressivePrimaryPurple, M3ExpressiveSecondaryPurple)),
            Triple("MONOCHROME", "Stealth Slate", Pair(M3ExpressivePrimaryMonochrome, M3ExpressiveSecondaryMonochrome))
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            presets.chunked(2).forEach { rowPresets ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    rowPresets.forEach { (key, title, colors) ->
                        val isSelected = themePreset == key

                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) activeColor else CockpitBorder,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { onThemePresetChange(key) },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) CockpitSurfaceVariant else CockpitSurface
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = title,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else Color.LightGray
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(14.dp)
                                            .clip(CircleShape)
                                            .background(colors.first)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(14.dp)
                                            .clip(CircleShape)
                                            .background(colors.second)
                                    )
                                }
                            }
                        }
                    }
                    if (rowPresets.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Material 3 Expressive Controls",
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontSize = 15.sp
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CockpitSurface)
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Strict Flat M3 Colors (NO NEON!)", fontWeight = FontWeight.Bold, color = Color.White)
                Text("Enforces clean Material 3 container colors without harsh neon glare", fontSize = 11.sp, color = Color.Gray)
            }
            Switch(
                checked = disableNeonGlow,
                onCheckedChange = onDisableNeonGlowChange,
                colors = SwitchDefaults.colors(checkedThumbColor = activeColor)
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CockpitSurface)
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Material 3 Expressive Shapes", fontWeight = FontWeight.Bold, color = Color.White)
                Text("Extra-rounded containers, rounded pads, and pill action buttons", fontSize = 11.sp, color = Color.Gray)
            }
            Switch(
                checked = isExpressiveShapes,
                onCheckedChange = onExpressiveShapesChange,
                colors = SwitchDefaults.colors(checkedThumbColor = activeColor)
            )
        }
    }
}

@Composable
private fun SettingSliderItem(
    title: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    onValueChange: (Float) -> Unit
) {
    val activeColor = MaterialTheme.colorScheme.primary

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, fontWeight = FontWeight.SemiBold, color = Color.White, fontSize = 13.sp)
            Text(valueText, fontWeight = FontWeight.Bold, color = activeColor, fontSize = 13.sp)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = activeColor,
                activeTrackColor = activeColor,
                inactiveTrackColor = CockpitSurfaceVariant
            )
        )
    }
}
