package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WheelDao {

    @Query("SELECT * FROM wheel_configs WHERE id = 1 LIMIT 1")
    fun getWheelConfig(): Flow<WheelConfigEntity?>

    @Query("SELECT * FROM wheel_configs WHERE id = 1 LIMIT 1")
    suspend fun getWheelConfigDirect(): WheelConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveWheelConfig(config: WheelConfigEntity)

    @Query("SELECT * FROM button_mappings")
    fun getAllButtonMappings(): Flow<List<ButtonMappingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertButtonMapping(button: ButtonMappingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllButtonMappings(buttons: List<ButtonMappingEntity>)

    @Query("DELETE FROM button_mappings WHERE id = :id")
    suspend fun deleteButtonMapping(id: Int)

    @Query("DELETE FROM button_mappings")
    suspend fun clearAllButtons()

    @Query("SELECT * FROM wheel_profiles")
    fun getAllProfiles(): Flow<List<WheelProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: WheelProfileEntity)
}
