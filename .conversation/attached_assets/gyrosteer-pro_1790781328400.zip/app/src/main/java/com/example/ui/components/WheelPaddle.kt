package com.example.ui.components

import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.CarbonLight
import com.example.ui.theme.RacingRed

@Composable
fun WheelPaddle(
    label: String,
    isRightPaddle: Boolean,
    colorHex: String = "",
    onPressChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var isPressed by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val activePrimary = MaterialTheme.colorScheme.primary

    val customColor = remember(colorHex) {
        if (colorHex.isNotBlank()) {
            try {
                Color(android.graphics.Color.parseColor(if (colorHex.startsWith("#")) colorHex else "#$colorHex"))
            } catch (e: Exception) {
                null
            }
        } else null
    }

    val baseColor = customColor ?: activePrimary

    val offsetX by animateFloatAsState(
        targetValue = if (isPressed) (if (isRightPaddle) -12f else 12f) else 0f,
        label = "paddle"
    )

    val borderColor by animateColorAsState(
        targetValue = if (isPressed) RacingRed else baseColor,
        label = "border"
    )

    val shape = if (isRightPaddle) {
        RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp)
    } else {
        RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp)
    }

    Box(
        modifier = modifier
            .width(68.dp)
            .fillMaxHeight(0.65f)
            .offset(x = offsetX.dp)
            .clip(shape)
            .background(
                brush = Brush.horizontalGradient(
                    colors = if (isPressed) listOf(RacingRed.copy(alpha = 0.8f), CarbonDark)
                             else listOf(CarbonLight, CarbonDark)
                )
            )
            .border(2.dp, borderColor, shape)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        onPressChanged(true)
                        vibrateClick(context)
                        tryAwaitRelease()
                        isPressed = false
                        onPressChanged(false)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 18.sp
        )
    }
}

private fun vibrateClick(context: android.content.Context) {
    try {
        @Suppress("DEPRECATION")
        val vibrator = context.getSystemService(android.content.Context.VIBRATOR_SERVICE) as? Vibrator
        if (vibrator?.hasVibrator() == true) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                vibrator.vibrate(30)
            }
        }
    } catch (_: Exception) {}
}
