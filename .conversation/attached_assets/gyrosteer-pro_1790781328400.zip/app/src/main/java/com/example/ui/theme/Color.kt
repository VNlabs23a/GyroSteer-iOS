package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cockpit Dark Surfaces
val CockpitBackground = Color(0xFF0F141C)
val CockpitSurface = Color(0xFF19202B)
val CockpitSurfaceVariant = Color(0xFF242C3B)
val CockpitBorder = Color(0xFF354154)

// Material 3 Expressive Primary Presets (NO NEON)
val M3ExpressivePrimaryBlue = Color(0xFF2563EB) // Expressive Royal Blue
val M3ExpressivePrimaryRed = Color(0xFFDC2626) // Expressive Racing Red
val M3ExpressivePrimaryAmber = Color(0xFFD97706) // Expressive Amber
val M3ExpressivePrimaryGreen = Color(0xFF16A34A) // Expressive Emerald
val M3ExpressivePrimaryPurple = Color(0xFF7C3AED) // Expressive Violet
val M3ExpressivePrimaryMonochrome = Color(0xFFE2E8F0) // Expressive Slate

// Secondary Accents
val M3ExpressiveSecondaryBlue = Color(0xFF60A5FA)
val M3ExpressiveSecondaryRed = Color(0xFFF87171)
val M3ExpressiveSecondaryAmber = Color(0xFFFBBF24)
val M3ExpressiveSecondaryGreen = Color(0xFF4ADE80)
val M3ExpressiveSecondaryPurple = Color(0xFFA78BFA)
val M3ExpressiveSecondaryMonochrome = Color(0xFF94A3B8)

// Accent / Status Colors
val RacingRed = Color(0xFFDC2626)
val AmberGold = Color(0xFFD97706)
val ShiftGreen = Color(0xFF16A34A)
val ShiftYellow = Color(0xFFCA8A04)
val ShiftRed = Color(0xFFDC2626)
val ShiftBlue = Color(0xFF2563EB)

val CarbonDark = Color(0xFF131720)
val CarbonLight = Color(0xFF222938)

// Alias for backwards compatibility pointing strictly to M3 Expressive Blue (NO NEON)
val NeonCyan = M3ExpressivePrimaryBlue

