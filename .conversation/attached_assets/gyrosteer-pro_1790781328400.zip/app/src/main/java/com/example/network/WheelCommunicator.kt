package com.example.network

import android.content.Context
import android.hardware.input.InputManager
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class TelemetryData(
    val speedKmh: Int = 0,
    val rpm: Int = 0,
    val maxRpm: Int = 8000,
    val gear: String = "N", // N, 1, 2, 3, 4, 5, 6, 7, R
    val tcActive: Boolean = false,
    val absActive: Boolean = false,
    val drsAvailable: Boolean = false,
    val pitLimiter: Boolean = false,
    val packetCount: Long = 0,
    val lastUpdateMs: Long = 0
)

data class ExternalGamepadState(
    val deviceName: String = "None Detected",
    val pedalAccelerator: Float = 0f, // 0.0 to 1.0
    val pedalBrake: Float = 0f,       // 0.0 to 1.0
    val pedalClutch: Float = 0f,      // 0.0 to 1.0
    val physicalButtonsPressed: List<String> = emptyList()
)

class WheelCommunicator(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var sendJob: Job? = null
    private var receiveJob: Job? = null

    private var socket: DatagramSocket? = null
    private var sequenceNumber: Int = 0

    // Configs
    var pcIpAddress: String = "192.168.1.100"
    var udpPort: Int = 8080
    var sendFrequencyHz: Int = 60
    var isBinaryProtocol: Boolean = true

    // Realtime input state
    @Volatile var currentSteeringAxis: Float = 0f
    @Volatile var currentWheelAngleDegrees: Float = 0f
    private val activeButtons = mutableSetOf<String>()

    // Status flows
    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _packetsSentCount = MutableStateFlow(0L)
    val packetsSentCount: StateFlow<Long> = _packetsSentCount.asStateFlow()

    private val _telemetryState = MutableStateFlow(TelemetryData())
    val telemetryState: StateFlow<TelemetryData> = _telemetryState.asStateFlow()

    private val _externalGamepadState = MutableStateFlow(ExternalGamepadState())
    val externalGamepadState: StateFlow<ExternalGamepadState> = _externalGamepadState.asStateFlow()

    fun setButtonState(actionCode: String, isPressed: Boolean) {
        synchronized(activeButtons) {
            if (isPressed) {
                activeButtons.add(actionCode)
            } else {
                activeButtons.remove(actionCode)
            }
        }
    }

    fun startCommunication() {
        stopCommunication()

        sendJob = scope.launch {
            try {
                socket = DatagramSocket()
                _isConnected.value = true
                startTelemetryReceiver()

                val delayMs = (1000.0f / sendFrequencyHz.coerceIn(10, 120)).toLong()
                while (sendJob?.isActive == true) {
                    sendDataPacket()
                    delay(delayMs)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                _isConnected.value = false
            }
        }
    }

    fun stopCommunication() {
        sendJob?.cancel()
        sendJob = null
        receiveJob?.cancel()
        receiveJob = null
        try {
            socket?.close()
        } catch (_: Exception) {}
        socket = null
        _isConnected.value = false
    }

    private suspend fun sendDataPacket() = withContext(Dispatchers.IO) {
        val currentSocket = socket ?: return@withContext
        try {
            val address = InetAddress.getByName(pcIpAddress)
            sequenceNumber++

            val buttonList: List<String>
            synchronized(activeButtons) {
                buttonList = activeButtons.toList()
            }

            val packetData: ByteArray = if (isBinaryProtocol) {
                buildBinaryPacket(sequenceNumber, currentSteeringAxis, currentWheelAngleDegrees, buttonList)
            } else {
                buildJsonPacket(sequenceNumber, currentSteeringAxis, currentWheelAngleDegrees, buttonList)
            }

            val datagram = DatagramPacket(packetData, packetData.size, address, udpPort)
            currentSocket.send(datagram)
            _packetsSentCount.value++
        } catch (_: Exception) {
            // Drop network errors on transient drop
        }
    }

    private fun buildBinaryPacket(
        seq: Int,
        steering: Float,
        angle: Float,
        buttons: List<String>
    ): ByteArray {
        val buffer = ByteBuffer.allocate(24)
        buffer.order(ByteOrder.LITTLE_ENDIAN)

        // Magic Header 'G' 'W'
        buffer.put('G'.code.toByte())
        buffer.put('W'.code.toByte())

        // Sequence
        buffer.putShort((seq and 0xFFFF).toShort())

        // Steering normalized [-1.0, 1.0]
        buffer.putFloat(steering)

        // Angle in degrees [-450.0, 450.0]
        buffer.putFloat(angle)

        // Button Bitmask
        var mask = 0
        if (buttons.contains("SHIFT_DOWN")) mask = mask or (1 shl 0)
        if (buttons.contains("SHIFT_UP")) mask = mask or (1 shl 1)
        if (buttons.contains("NITRO")) mask = mask or (1 shl 2)
        if (buttons.contains("HANDBRAKE")) mask = mask or (1 shl 3)
        if (buttons.contains("DRS")) mask = mask or (1 shl 4)
        if (buttons.contains("HORN")) mask = mask or (1 shl 5)
        if (buttons.contains("TC_PLUS")) mask = mask or (1 shl 6)
        if (buttons.contains("TC_MINUS")) mask = mask or (1 shl 7)
        if (buttons.contains("ABS_PLUS")) mask = mask or (1 shl 8)
        if (buttons.contains("ABS_MINUS")) mask = mask or (1 shl 9)
        if (buttons.contains("PIT")) mask = mask or (1 shl 10)
        if (buttons.contains("PAUSE")) mask = mask or (1 shl 11)

        buffer.putInt(mask)

        // External pedals if connected via OTG
        val pedals = externalGamepadState.value
        buffer.putFloat(pedals.pedalAccelerator)
        buffer.putFloat(pedals.pedalBrake)

        return buffer.array()
    }

    private fun buildJsonPacket(
        seq: Int,
        steering: Float,
        angle: Float,
        buttons: List<String>
    ): ByteArray {
        val json = JSONObject().apply {
            put("seq", seq)
            put("steering", Math.round(steering * 1000.0) / 1000.0)
            put("angle", Math.round(angle * 10.0) / 10.0)
            put("buttons", buttons.joinToString(","))
            put("accel", externalGamepadState.value.pedalAccelerator)
            put("brake", externalGamepadState.value.pedalBrake)
        }
        return json.toString().toByteArray(Charsets.UTF_8)
    }

    private fun startTelemetryReceiver() {
        receiveJob = scope.launch {
            val listenPort = udpPort + 1 // e.g. 8081 for inbound PC telemetry
            var recvSocket: DatagramSocket? = null
            try {
                recvSocket = DatagramSocket(listenPort)
                val buffer = ByteArray(1024)
                while (receiveJob?.isActive == true) {
                    val packet = DatagramPacket(buffer, buffer.size)
                    recvSocket.receive(packet)
                    val jsonStr = String(packet.data, 0, packet.length, Charsets.UTF_8)
                    parseTelemetryPacket(jsonStr)
                }
            } catch (_: Exception) {
            } finally {
                try { recvSocket?.close() } catch (_: Exception) {}
            }
        }
    }

    private fun parseTelemetryPacket(jsonStr: String) {
        try {
            val obj = JSONObject(jsonStr)
            val current = _telemetryState.value
            _telemetryState.value = current.copy(
                speedKmh = obj.optInt("speed", current.speedKmh),
                rpm = obj.optInt("rpm", current.rpm),
                maxRpm = obj.optInt("maxRpm", current.maxRpm),
                gear = obj.optString("gear", current.gear),
                tcActive = obj.optBoolean("tc", current.tcActive),
                absActive = obj.optBoolean("abs", current.absActive),
                drsAvailable = obj.optBoolean("drs", current.drsAvailable),
                pitLimiter = obj.optBoolean("pit", current.pitLimiter),
                packetCount = current.packetCount + 1,
                lastUpdateMs = SystemClock.elapsedRealtime()
            )
        } catch (_: Exception) {}
    }

    // USB OTG Gamepad / Physical Controller detection
    fun processGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) {
            val deviceName = event.device?.name ?: "USB Gamepad"
            val accel = event.getAxisValue(MotionEvent.AXIS_GAS).takeIf { it != 0f }
                ?: event.getAxisValue(MotionEvent.AXIS_RTRIGGER)
                ?: ((event.getAxisValue(MotionEvent.AXIS_RZ) + 1f) / 2f)
            val brake = event.getAxisValue(MotionEvent.AXIS_BRAKE).takeIf { it != 0f }
                ?: event.getAxisValue(MotionEvent.AXIS_LTRIGGER)
                ?: ((event.getAxisValue(MotionEvent.AXIS_Z) + 1f) / 2f)

            _externalGamepadState.value = _externalGamepadState.value.copy(
                deviceName = deviceName,
                pedalAccelerator = accel.coerceIn(0f, 1f),
                pedalBrake = brake.coerceIn(0f, 1f)
            )
            return true
        }
        return false
    }

    fun processKeyEvent(event: KeyEvent): Boolean {
        val deviceName = event.device?.name ?: "USB Gamepad"
        val isDown = event.action == KeyEvent.ACTION_DOWN
        val buttonName = KeyEvent.keyCodeToString(event.keyCode)

        val currentPressed = _externalGamepadState.value.physicalButtonsPressed.toMutableList()
        if (isDown && !currentPressed.contains(buttonName)) {
            currentPressed.add(buttonName)
        } else if (!isDown) {
            currentPressed.remove(buttonName)
        }

        _externalGamepadState.value = _externalGamepadState.value.copy(
            deviceName = deviceName,
            physicalButtonsPressed = currentPressed
        )
        return false
    }
}
