package com.example.ui

import android.app.Application
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ButtonMappingEntity
import com.example.data.WheelConfigEntity
import com.example.data.WheelDatabase
import com.example.data.WheelProfileEntity
import com.example.data.WheelRepository
import com.example.network.ExternalGamepadState
import com.example.network.PcReceiverScriptGenerator
import com.example.network.TelemetryData
import com.example.network.WheelCommunicator
import com.example.sensor.GyroWheelSensorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WheelViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = WheelRepository(WheelDatabase.getInstance(application).wheelDao())

    val configState: StateFlow<WheelConfigEntity?> = repository.configFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val buttonMappingsState: StateFlow<List<ButtonMappingEntity>> = repository.buttonMappingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val profilesState: StateFlow<List<WheelProfileEntity>> = repository.profilesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Real-time Wheel Angle State
    private val _wheelAngleDegrees = MutableStateFlow(0f)
    val wheelAngleDegrees: StateFlow<Float> = _wheelAngleDegrees.asStateFlow()

    private val _normalizedSteering = MutableStateFlow(0f)
    val normalizedSteering: StateFlow<Float> = _normalizedSteering.asStateFlow()

    private val _isNearLock = MutableStateFlow(false)
    val isNearLock: StateFlow<Boolean> = _isNearLock.asStateFlow()

    // UI Dialog & Mode States
    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    private val _isMappingEditorOpen = MutableStateFlow(false)
    val isMappingEditorOpen: StateFlow<Boolean> = _isMappingEditorOpen.asStateFlow()

    private val _isPcScriptOpen = MutableStateFlow(false)
    val isPcScriptOpen: StateFlow<Boolean> = _isPcScriptOpen.asStateFlow()

    private val _isSimulatedTelemetryEnabled = MutableStateFlow(false)
    val isSimulatedTelemetryEnabled: StateFlow<Boolean> = _isSimulatedTelemetryEnabled.asStateFlow()
    
    private val _leftBlinker = MutableStateFlow(false)
    val leftBlinker: StateFlow<Boolean> = _leftBlinker.asStateFlow()
    
    private val _rightBlinker = MutableStateFlow(false)
    val rightBlinker: StateFlow<Boolean> = _rightBlinker.asStateFlow()

    // Sensor & Network Engines
    val sensorManager = GyroWheelSensorManager(
        context = application,
        onAngleChanged = { rawAngle, normalized, nearLock ->
            _wheelAngleDegrees.value = rawAngle
            _normalizedSteering.value = normalized
            _isNearLock.value = nearLock
            communicator.currentSteeringAxis = normalized
            communicator.currentWheelAngleDegrees = rawAngle
        }
    )

    val communicator = WheelCommunicator(application)

    val isConnected: StateFlow<Boolean> = communicator.isConnected
    val packetsSentCount: StateFlow<Long> = communicator.packetsSentCount
    val telemetryState: StateFlow<TelemetryData> = communicator.telemetryState
    val externalGamepadState: StateFlow<ExternalGamepadState> = communicator.externalGamepadState

    init {
        viewModelScope.launch {
            repository.initializeDefaultsIfEmpty()

            configState.collectLatest { cfg ->
                if (cfg != null) {
                    // Update Sensor Engine parameters
                    sensorManager.maxAngleDegrees = cfg.maxAngleDegrees
                    sensorManager.deadzonePercentage = cfg.deadzonePercentage
                    sensorManager.linearity = cfg.steeringLinearity
                    sensorManager.smoothingFactor = cfg.smoothingFactor
                    sensorManager.rattleFilter = cfg.rattleFilter
                    sensorManager.autoRecenterEnabled = cfg.autoRecenterEnabled
                    sensorManager.hapticLockEnabled = cfg.hapticLockEnabled
                    sensorManager.hapticIntensity = cfg.hapticIntensity
                    sensorManager.hapticLockMarginDegrees = cfg.hapticLockMarginDegrees

                    // Update Network Communicator parameters
                    communicator.pcIpAddress = cfg.pcIpAddress
                    communicator.udpPort = cfg.udpPort
                    communicator.sendFrequencyHz = cfg.sendFrequencyHz
                    communicator.isBinaryProtocol = cfg.protocolMode == "BINARY"
                }
            }
        }
    }

    fun startWheel() {
        sensorManager.start()
        communicator.startCommunication()
    }

    fun stopWheel() {
        sensorManager.stop()
        communicator.stopCommunication()
    }

    fun recenterWheel() {
        sensorManager.recenter()
    }

    fun calibrateZeroPoint() {
        sensorManager.calibrateZeroPoint()
    }

    fun setButtonPressed(actionCode: String, isPressed: Boolean) {
        if (isPressed) {
            when (actionCode) {
                "BLINKER_L" -> {
                    _leftBlinker.value = !_leftBlinker.value
                    _rightBlinker.value = false
                }
                "BLINKER_R" -> {
                    _rightBlinker.value = !_rightBlinker.value
                    _leftBlinker.value = false
                }
                "NITRO" -> {
                    _leftBlinker.value = false
                    _rightBlinker.value = false
                }
            }
        }
        communicator.setButtonState(actionCode, isPressed)
    }

    fun applyBusLayout() {
        viewModelScope.launch {
            repository.applyBusLayout()
        }
    }

    fun applyDefaultLayout() {
        viewModelScope.launch {
            repository.applyDefaultLayout()
        }
    }

    fun updateConfig(updated: WheelConfigEntity) {
        viewModelScope.launch {
            repository.saveConfig(updated)
            communicator.startCommunication() // Restart network socket with updated IP/port
        }
    }

    fun saveButtonMapping(mapping: ButtonMappingEntity) {
        viewModelScope.launch {
            repository.saveButtonMapping(mapping)
        }
    }

    fun deleteButtonMapping(id: Int) {
        viewModelScope.launch {
            repository.deleteButtonMapping(id)
        }
    }

    fun applyProfile(profile: WheelProfileEntity) {
        viewModelScope.launch {
            val current = repository.getWheelConfigDirect()
            val updated = current.copy(
                maxAngleDegrees = profile.maxAngleDegrees,
                steeringLinearity = profile.linearity,
                deadzonePercentage = profile.deadzone,
                activeProfileName = profile.name
            )
            repository.saveConfig(updated)
        }
    }

    fun toggleSettingsDialog(show: Boolean) {
        _isSettingsOpen.value = show
    }

    fun toggleMappingEditor(show: Boolean) {
        _isMappingEditorOpen.value = show
    }

    fun togglePcScriptDialog(show: Boolean) {
        _isPcScriptOpen.value = show
    }

    fun toggleSimulatedTelemetry(enabled: Boolean) {
        _isSimulatedTelemetryEnabled.value = enabled
    }

    fun getGeneratedPythonScript(): String {
        val port = configState.value?.udpPort ?: 8080
        return PcReceiverScriptGenerator.generatePythonVJoyScript(port)
    }

    fun handleGenericMotionEvent(event: MotionEvent): Boolean {
        return communicator.processGenericMotionEvent(event)
    }

    fun handleKeyEvent(event: KeyEvent): Boolean {
        return communicator.processKeyEvent(event)
    }

    override fun onCleared() {
        super.onCleared()
        stopWheel()
    }
}
