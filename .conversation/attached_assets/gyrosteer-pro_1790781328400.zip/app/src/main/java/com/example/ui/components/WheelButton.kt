package com.example.ui.components

import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CockpitSurfaceVariant
import com.example.ui.theme.RacingRed

@Composable
fun WheelButton(
    label: String,
    actionCode: String,
    sizeScale: Float = 1.0f,
    colorHex: String = "",
    onPressChanged: (Boolean) -> Unit,
    isEditMode: Boolean = false,
    onSelectInEditMode: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var isPressed by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val primaryColor = MaterialTheme.colorScheme.primary

    val customColor = remember(colorHex) {
        if (colorHex.isNotBlank()) {
            try {
                Color(android.graphics.Color.parseColor(if (colorHex.startsWith("#")) colorHex else "#$colorHex"))
            } catch (e: Exception) {
                null
            }
        } else null
    }

    val buttonColor by animateColorAsState(
        targetValue = when {
            isPressed -> RacingRed
            customColor != null -> customColor
            actionCode.contains("NITRO") -> AmberGold
            actionCode.contains("DRS") -> primaryColor
            else -> CockpitSurfaceVariant
        },
        label = "btnBg"
    )

    val textColor = if (isPressed || customColor != null || actionCode.contains("NITRO") || actionCode.contains("DRS")) {
        Color.Black
    } else {
        Color.White
    }

    val scaledSize = 54.dp * sizeScale

    Box(
        modifier = modifier
            .size(scaledSize)
            .clip(CircleShape)
            .background(buttonColor)
            .border(2.dp, if (isEditMode) AmberGold else primaryColor, CircleShape)
            .pointerInput(isEditMode) {
                if (isEditMode) {
                    detectTapGestures(
                        onTap = { onSelectInEditMode() }
                    )
                } else {
                    detectTapGestures(
                        onPress = {
                            isPressed = true
                            onPressChanged(true)
                            vibrateClick(context)
                            tryAwaitRelease()
                            isPressed = false
                            onPressChanged(false)
                        }
                    )
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

private fun vibrateClick(context: android.content.Context) {
    try {
        @Suppress("DEPRECATION")
        val vibrator = context.getSystemService(android.content.Context.VIBRATOR_SERVICE) as? Vibrator
        if (vibrator?.hasVibrator() == true) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                vibrator.vibrate(20)
            }
        }
    } catch (_: Exception) {}
}
