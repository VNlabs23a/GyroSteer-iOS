package com.example.data

import kotlinx.coroutines.flow.Flow

class WheelRepository(private val dao: WheelDao) {

    val configFlow: Flow<WheelConfigEntity?> = dao.getWheelConfig()
    val buttonMappingsFlow: Flow<List<ButtonMappingEntity>> = dao.getAllButtonMappings()
    val profilesFlow: Flow<List<WheelProfileEntity>> = dao.getAllProfiles()

    suspend fun getWheelConfigDirect(): WheelConfigEntity {
        return dao.getWheelConfigDirect() ?: WheelConfigEntity()
    }

    suspend fun saveConfig(config: WheelConfigEntity) {
        dao.saveWheelConfig(config)
    }

    suspend fun saveButtonMapping(mapping: ButtonMappingEntity) {
        dao.insertButtonMapping(mapping)
    }

    suspend fun deleteButtonMapping(id: Int) {
        dao.deleteButtonMapping(id)
    }

    suspend fun applyBusLayout() {
        dao.clearAllButtons()
        val busButtons = listOf(
            ButtonMappingEntity(
                buttonId = "paddle_l",
                label = "BLINKER L",
                xRatio = 0.08f,
                yRatio = 0.45f,
                actionCode = "BLINKER_L",
                isPaddle = true
            ),
            ButtonMappingEntity(
                buttonId = "paddle_r",
                label = "BLINKER R",
                xRatio = 0.92f,
                yRatio = 0.45f,
                actionCode = "BLINKER_R",
                isPaddle = true
            ),
            ButtonMappingEntity(
                buttonId = "btn_nitro_cancel",
                label = "CANCEL BLINK",
                xRatio = 0.78f,
                yRatio = 0.25f,
                actionCode = "NITRO"
            ),
            ButtonMappingEntity(
                buttonId = "btn_horn",
                label = "HORN",
                xRatio = 0.22f,
                yRatio = 0.25f,
                actionCode = "HORN"
            ),
            ButtonMappingEntity(
                buttonId = "btn_handbrake",
                label = "H-BRAKE",
                xRatio = 0.82f,
                yRatio = 0.72f,
                actionCode = "HANDBRAKE"
            )
        )
        dao.insertAllButtonMappings(busButtons)
    }

    suspend fun applyDefaultLayout() {
        dao.clearAllButtons()
        val defaultButtons = listOf(
            ButtonMappingEntity(
                buttonId = "paddle_l",
                label = "DOWN -",
                xRatio = 0.08f,
                yRatio = 0.45f,
                actionCode = "SHIFT_DOWN",
                isPaddle = true
            ),
            ButtonMappingEntity(
                buttonId = "paddle_r",
                label = "UP +",
                xRatio = 0.92f,
                yRatio = 0.45f,
                actionCode = "SHIFT_UP",
                isPaddle = true
            ),
            ButtonMappingEntity(
                buttonId = "btn_drs",
                label = "DRS",
                xRatio = 0.22f,
                yRatio = 0.25f,
                actionCode = "DRS"
            ),
            ButtonMappingEntity(
                buttonId = "btn_nitro",
                label = "NITRO",
                xRatio = 0.78f,
                yRatio = 0.25f,
                actionCode = "NITRO"
            ),
            ButtonMappingEntity(
                buttonId = "btn_handbrake",
                label = "H-BRAKE",
                xRatio = 0.18f,
                yRatio = 0.72f,
                actionCode = "HANDBRAKE"
            ),
            ButtonMappingEntity(
                buttonId = "btn_horn",
                label = "HORN",
                xRatio = 0.82f,
                yRatio = 0.72f,
                actionCode = "HORN"
            ),
            ButtonMappingEntity(
                buttonId = "btn_tc_plus",
                label = "TC +",
                xRatio = 0.32f,
                yRatio = 0.82f,
                actionCode = "TC_PLUS"
            ),
            ButtonMappingEntity(
                buttonId = "btn_tc_minus",
                label = "TC -",
                xRatio = 0.32f,
                yRatio = 0.92f,
                actionCode = "TC_MINUS"
            ),
            ButtonMappingEntity(
                buttonId = "btn_pit",
                label = "PIT",
                xRatio = 0.68f,
                yRatio = 0.82f,
                actionCode = "PIT"
            ),
            ButtonMappingEntity(
                buttonId = "btn_pause",
                label = "PAUSE",
                xRatio = 0.68f,
                yRatio = 0.92f,
                actionCode = "PAUSE"
            )
        )
        dao.insertAllButtonMappings(defaultButtons)
    }

    suspend fun saveProfile(profile: WheelProfileEntity) {
        dao.insertProfile(profile)
    }

    suspend fun initializeDefaultsIfEmpty() {
        val config = dao.getWheelConfigDirect()
        if (config == null) {
            dao.saveWheelConfig(WheelConfigEntity())
            
            // Insert default button mappings
            val defaultButtons = listOf(
                ButtonMappingEntity(
                    buttonId = "paddle_l",
                    label = "DOWN -",
                    xRatio = 0.08f,
                    yRatio = 0.45f,
                    actionCode = "SHIFT_DOWN",
                    isPaddle = true
                ),
                ButtonMappingEntity(
                    buttonId = "paddle_r",
                    label = "UP +",
                    xRatio = 0.92f,
                    yRatio = 0.45f,
                    actionCode = "SHIFT_UP",
                    isPaddle = true
                ),
                ButtonMappingEntity(
                    buttonId = "btn_drs",
                    label = "DRS",
                    xRatio = 0.22f,
                    yRatio = 0.25f,
                    actionCode = "DRS"
                ),
                ButtonMappingEntity(
                    buttonId = "btn_nitro",
                    label = "NITRO",
                    xRatio = 0.78f,
                    yRatio = 0.25f,
                    actionCode = "NITRO"
                ),
                ButtonMappingEntity(
                    buttonId = "btn_handbrake",
                    label = "H-BRAKE",
                    xRatio = 0.18f,
                    yRatio = 0.72f,
                    actionCode = "HANDBRAKE"
                ),
                ButtonMappingEntity(
                    buttonId = "btn_horn",
                    label = "HORN",
                    xRatio = 0.82f,
                    yRatio = 0.72f,
                    actionCode = "HORN"
                ),
                ButtonMappingEntity(
                    buttonId = "btn_tc_plus",
                    label = "TC +",
                    xRatio = 0.32f,
                    yRatio = 0.82f,
                    actionCode = "TC_PLUS"
                ),
                ButtonMappingEntity(
                    buttonId = "btn_tc_minus",
                    label = "TC -",
                    xRatio = 0.32f,
                    yRatio = 0.92f,
                    actionCode = "TC_MINUS"
                ),
                ButtonMappingEntity(
                    buttonId = "btn_pit",
                    label = "PIT",
                    xRatio = 0.68f,
                    yRatio = 0.82f,
                    actionCode = "PIT"
                ),
                ButtonMappingEntity(
                    buttonId = "btn_pause",
                    label = "PAUSE",
                    xRatio = 0.68f,
                    yRatio = 0.92f,
                    actionCode = "PAUSE"
                )
            )
            dao.insertAllButtonMappings(defaultButtons)

            // Default profiles
            val defaultProfiles = listOf(
                WheelProfileEntity(
                    name = "900° Standard / Drift",
                    maxAngleDegrees = 900f,
                    linearity = 1.0f,
                    deadzone = 1.5f,
                    description = "2.5 full rotations lock-to-lock for realistic road, rally, and drift cars."
                ),
                WheelProfileEntity(
                    name = "540° Rally / GT3",
                    maxAngleDegrees = 540f,
                    linearity = 1.1f,
                    deadzone = 1.0f,
                    description = "1.5 turns lock-to-lock for agile rally and GT3 cars."
                ),
                WheelProfileEntity(
                    name = "360° F1 / Supercar",
                    maxAngleDegrees = 360f,
                    linearity = 1.2f,
                    deadzone = 0.5f,
                    description = "1 full turn lock-to-lock for high speed formula racing."
                ),
                WheelProfileEntity(
                    name = "1080° Heavy Truck",
                    maxAngleDegrees = 1080f,
                    linearity = 1.0f,
                    deadzone = 2.0f,
                    description = "3 full rotations lock-to-lock for Euro Truck & American Truck Simulator."
                ),
                WheelProfileEntity(
                    name = "1800° Bus Preset",
                    maxAngleDegrees = 1800f,
                    linearity = 1.0f,
                    deadzone = 2.0f,
                    description = "5 full rotations for extreme heavy buses and coaches."
                )
            )
            for (p in defaultProfiles) {
                dao.insertProfile(p)
            }
        }
    }
}
