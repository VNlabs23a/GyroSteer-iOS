package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.SteeringPositionIndicatorBar
import com.example.ui.components.SteeringWheelCanvas
import com.example.ui.components.VirtualDashboardView
import com.example.ui.components.WheelButton
import com.example.ui.components.WheelPaddle
import com.example.ui.dialogs.ButtonMappingEditorDialog
import com.example.ui.dialogs.PcScriptDialog
import com.example.ui.dialogs.SettingsAndCalibrationDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CockpitBackground
import com.example.ui.theme.CockpitSurface
import com.example.ui.theme.CockpitSurfaceVariant
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.RacingRed
import com.example.ui.theme.ShiftGreen
import kotlinx.coroutines.delay

@Composable
fun MainWheelScreen(
    viewModel: WheelViewModel,
    modifier: Modifier = Modifier
) {
    val config by viewModel.configState.collectAsStateWithLifecycle()
    val buttonMappings by viewModel.buttonMappingsState.collectAsStateWithLifecycle()
    val profiles by viewModel.profilesState.collectAsStateWithLifecycle()

    val wheelAngle by viewModel.wheelAngleDegrees.collectAsStateWithLifecycle()
    val normalizedSteering by viewModel.normalizedSteering.collectAsStateWithLifecycle()
    val isNearLock by viewModel.isNearLock.collectAsStateWithLifecycle()

    val isConnected by viewModel.isConnected.collectAsStateWithLifecycle()
    val packetsSent by viewModel.packetsSentCount.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetryState.collectAsStateWithLifecycle()
    val externalGamepad by viewModel.externalGamepadState.collectAsStateWithLifecycle()

    val leftBlinker by viewModel.leftBlinker.collectAsStateWithLifecycle()
    val rightBlinker by viewModel.rightBlinker.collectAsStateWithLifecycle()

    val isSettingsOpen by viewModel.isSettingsOpen.collectAsStateWithLifecycle()
    val isMappingEditorOpen by viewModel.isMappingEditorOpen.collectAsStateWithLifecycle()
    val isPcScriptOpen by viewModel.isPcScriptOpen.collectAsStateWithLifecycle()
    val isSimulatedTelemetry by viewModel.isSimulatedTelemetryEnabled.collectAsStateWithLifecycle()

    // Start/Stop Sensor and Network when screen is displayed
    DisposableEffect(Unit) {
        viewModel.startWheel()
        onDispose {
            viewModel.stopWheel()
        }
    }

    // Optional simulated telemetry generator for demo/offline previewing
    LaunchedEffect(isSimulatedTelemetry) {
        if (isSimulatedTelemetry) {
            var simSpeed = 80
            var simRpm = 4500
            var gearIdx = 3
            val gears = listOf("N", "1", "2", "3", "4", "5", "6", "7")
            while (true) {
                delay(100)
                simSpeed = (simSpeed + 1).let { if (it > 280) 60 else it }
                simRpm = (simRpm + 120).let { if (it > 8200) 3500 else it }
                if (simRpm > 7800 && gearIdx < gears.size - 1) gearIdx++
                val simulatedData = telemetry.copy(
                    speedKmh = simSpeed,
                    rpm = simRpm,
                    maxRpm = 8500,
                    gear = gears[gearIdx],
                    tcActive = simSpeed % 10 < 3,
                    absActive = simSpeed > 200,
                    drsAvailable = true
                )
                viewModel.communicator.setButtonState("SIM_DATA", false) // tick
            }
        }
    }

    val maxAngle = config?.maxAngleDegrees ?: 900f

    Surface(
        modifier = modifier.fillMaxSize(),
        color = CockpitBackground
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            
            // Cockpit Background Texture Accents
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(CockpitBackground)
            )

            // Main Wheel & Controls Layer
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Control Bar
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(CockpitSurface)
                            .padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Connection Status Badge
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (isConnected) ShiftGreen else RacingRed)
                            )
                            Text(
                                text = if (isConnected) "UDP OUT: ${config?.pcIpAddress}:${config?.udpPort}" else "Connecting...",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        // Angle Readout Center
                        val angleStr = String.format("%+.1f°", wheelAngle)
                        Text(
                            text = "WHEEL: $angleStr",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = if (isNearLock) RacingRed else MaterialTheme.colorScheme.primary
                        )

                        // Quick Action Buttons
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = { viewModel.recenterWheel() }) {
                                Icon(Icons.Default.Refresh, contentDescription = "Recenter Wheel", tint = AmberGold)
                            }

                            IconButton(onClick = { viewModel.toggleSimulatedTelemetry(!isSimulatedTelemetry) }) {
                                Icon(
                                    Icons.Default.Speed,
                                    contentDescription = "Toggle Sim Telemetry",
                                    tint = if (isSimulatedTelemetry) ShiftGreen else Color.Gray
                                )
                            }

                            IconButton(onClick = { viewModel.toggleMappingEditor(true) }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Buttons", tint = MaterialTheme.colorScheme.primary)
                            }

                            IconButton(onClick = { viewModel.toggleSettingsDialog(true) }) {
                                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                            }
                        }
                    }

                    // Top Full-Width Steering Wheel Position Bar
                    SteeringPositionIndicatorBar(
                        wheelAngleDegrees = wheelAngle,
                        maxAngleDegrees = maxAngle,
                        deadzonePercentage = config?.deadzonePercentage ?: 2.0f,
                        isNearLock = isNearLock
                    )
                }

                // Center Steering Wheel & Paddle Shifter View Area
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    // Left Paddle Shifter
                    WheelPaddle(
                        label = "-",
                        isRightPaddle = false,
                        colorHex = config?.paddleColorHex ?: "",
                        onPressChanged = { isPressed ->
                            viewModel.setButtonPressed("SHIFT_DOWN", isPressed)
                        },
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .scale(config?.paddleSizeScale ?: 1.0f)
                    )

                    // Right Paddle Shifter
                    WheelPaddle(
                        label = "+",
                        isRightPaddle = true,
                        colorHex = config?.paddleColorHex ?: "",
                        onPressChanged = { isPressed ->
                            viewModel.setButtonPressed("SHIFT_UP", isPressed)
                        },
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .scale(config?.paddleSizeScale ?: 1.0f)
                    )

                    // Steering Wheel Visual Canvas
                    SteeringWheelCanvas(
                        angleDegrees = wheelAngle,
                        isNearLock = isNearLock,
                        colorHex = config?.wheelColorHex ?: "",
                        modifier = Modifier
                            .size((config?.wheelSizeDp ?: 280f).dp)
                            .offset(x = (config?.wheelXOffsetDp ?: 0f).dp, y = (config?.wheelYOffsetDp ?: 0f).dp)
                    ) {
                        // Center Virtual Telemetry Dashboard
                        VirtualDashboardView(
                            telemetry = telemetry,
                            wheelAngleDegrees = wheelAngle,
                            maxAngleDegrees = maxAngle,
                            isConnected = isConnected,
                            leftBlinker = leftBlinker,
                            rightBlinker = rightBlinker,
                            onSimulateShiftUp = { viewModel.setButtonPressed("SHIFT_UP", true) },
                            onSimulateShiftDown = { viewModel.setButtonPressed("SHIFT_DOWN", true) },
                            modifier = Modifier.size(width = 180.dp, height = 120.dp)
                        )
                    }

                    // Render On-Screen Touch Buttons based on database mappings
                    buttonMappings.filter { !it.isPaddle }.forEach { btn ->
                        // Calculate offset from percentage
                        val xOffset = ((btn.xRatio - 0.5f) * 600).dp
                        val yOffset = ((btn.yRatio - 0.5f) * 280).dp

                        WheelButton(
                            label = btn.label,
                            actionCode = btn.actionCode,
                            sizeScale = btn.sizeScale,
                            colorHex = btn.colorHex,
                            onPressChanged = { isPressed ->
                                viewModel.setButtonPressed(btn.actionCode, isPressed)
                            },
                            modifier = Modifier.offset(x = xOffset, y = yOffset)
                        )
                    }

                    // Easily Reachable Thumb Recenter Quick Action (Bottom-Left)
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(bottom = 4.dp, start = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(AmberGold)
                            .clickable { viewModel.recenterWheel() }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = "Recenter", tint = Color.Black, modifier = Modifier.size(16.dp))
                            Text("RECENTER", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color.Black)
                        }
                    }

                    // Easily Reachable Thumb Recenter Quick Action (Bottom-Right)
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(bottom = 4.dp, end = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(AmberGold)
                            .clickable { viewModel.recenterWheel() }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = "Recenter", tint = Color.Black, modifier = Modifier.size(16.dp))
                            Text("RECENTER", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color.Black)
                        }
                    }
                }

                // Bottom Stats & Info Strip
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CockpitSurfaceVariant)
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PROFILE: ${config?.activeProfileName ?: "900° Standard"}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberGold
                    )

                    Text(
                        text = "PACKETS: $packetsSent | ${config?.sendFrequencyHz ?: 60}Hz",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray
                    )

                    Text(
                        text = if (externalGamepad.deviceName != "None Detected") "OTG: ${externalGamepad.deviceName}" else "LOCK HAPTICS: ON",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Dialog Overlays
            if (isSettingsOpen && config != null) {
                SettingsAndCalibrationDialog(
                    config = config!!,
                    profiles = profiles,
                    externalGamepad = externalGamepad,
                    onDismiss = { viewModel.toggleSettingsDialog(false) },
                    onSaveConfig = { updated -> viewModel.updateConfig(updated) },
                    onRecenter = { viewModel.recenterWheel() },
                    onCalibrateZero = { viewModel.calibrateZeroPoint() },
                    onApplyProfile = { profile -> viewModel.applyProfile(profile) },
                    onOpenPcScript = {
                        viewModel.toggleSettingsDialog(false)
                        viewModel.togglePcScriptDialog(true)
                    }
                )
            }

            if (isMappingEditorOpen) {
                ButtonMappingEditorDialog(
                    buttonMappings = buttonMappings,
                    onDismiss = { viewModel.toggleMappingEditor(false) },
                    onSaveButton = { btn -> viewModel.saveButtonMapping(btn) },
                    onDeleteButton = { id -> viewModel.deleteButtonMapping(id) },
                    onLoadBusLayout = { viewModel.applyBusLayout() },
                    onLoadDefaultLayout = { viewModel.applyDefaultLayout() }
                )
            }

            if (isPcScriptOpen) {
                PcScriptDialog(
                    pythonScript = viewModel.getGeneratedPythonScript(),
                    onDismiss = { viewModel.togglePcScriptDialog(false) }
                )
            }
        }
    }
}
