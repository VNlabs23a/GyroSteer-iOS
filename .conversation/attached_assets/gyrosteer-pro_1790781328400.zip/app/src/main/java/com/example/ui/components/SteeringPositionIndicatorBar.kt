package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CockpitBorder
import com.example.ui.theme.CockpitSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.RacingRed
import kotlin.math.abs

@Composable
fun SteeringPositionIndicatorBar(
    wheelAngleDegrees: Float,
    maxAngleDegrees: Float,
    deadzonePercentage: Float,
    isNearLock: Boolean,
    modifier: Modifier = Modifier
) {
    val halfMax = (maxAngleDegrees / 2.0f).coerceAtLeast(1f)
    val clampedAngle = wheelAngleDegrees.coerceIn(-halfMax, halfMax)

    val animatedAngle by animateFloatAsState(
        targetValue = clampedAngle,
        animationSpec = tween(durationMillis = 30),
        label = "wheelAngle"
    )

    val activePrimary = MaterialTheme.colorScheme.primary

    val barColor by animateColorAsState(
        targetValue = if (isNearLock) RacingRed else activePrimary,
        animationSpec = tween(durationMillis = 150),
        label = "barColor"
    )

    val trackColor = CockpitSurface
    val borderColor = CockpitBorder

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(trackColor)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        // Canvas Bar Indicator
        Canvas(modifier = Modifier.fillMaxWidth().fillMaxHeight()) {
            val width = size.width
            val height = size.height
            val centerX = width / 2f
            val deadzoneFrac = (deadzonePercentage / 100f).coerceIn(0f, 0.25f)

            // Draw Background Center Tick
            drawLine(
                color = Color.Gray.copy(alpha = 0.5f),
                start = Offset(centerX, 0f),
                end = Offset(centerX, height),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Draw Deadzone Markers
            val deadzonePx = (width / 2f) * deadzoneFrac
            if (deadzonePx > 2f) {
                drawLine(
                    color = Color.DarkGray,
                    start = Offset(centerX - deadzonePx, 2f),
                    end = Offset(centerX - deadzonePx, height - 2f),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = Color.DarkGray,
                    start = Offset(centerX + deadzonePx, 2f),
                    end = Offset(centerX + deadzonePx, height - 2f),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // Draw Left/Right Max Lock Endlines
            drawLine(
                color = RacingRed.copy(alpha = 0.8f),
                start = Offset(4.dp.toPx(), 4.dp.toPx()),
                end = Offset(4.dp.toPx(), height - 4.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )
            drawLine(
                color = RacingRed.copy(alpha = 0.8f),
                start = Offset(width - 4.dp.toPx(), 4.dp.toPx()),
                end = Offset(width - 4.dp.toPx(), height - 4.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )

            // Calculate active steering position
            val normalizedPos = (animatedAngle / halfMax).coerceIn(-1f, 1f)
            val posX = centerX + (normalizedPos * (width / 2f - 6.dp.toPx()))

            // Active fill bar from center to position
            val fillLeft = if (posX < centerX) posX else centerX
            val fillWidth = abs(posX - centerX).coerceAtLeast(2f)

            drawRect(
                color = barColor.copy(alpha = 0.85f),
                topLeft = Offset(fillLeft, 4.dp.toPx()),
                size = Size(fillWidth, height - 8.dp.toPx())
            )

            // Position Indicator Thumb/Pill
            drawCircle(
                color = barColor,
                radius = 6.dp.toPx(),
                center = Offset(posX, height / 2f)
            )
            drawCircle(
                color = Color.White,
                radius = 2.dp.toPx(),
                center = Offset(posX, height / 2f)
            )
        }

        // Angle Readout Text overlay
        Row(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val angleStr = String.format("%+.1f°", animatedAngle)
            Text(
                text = angleStr,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = if (isNearLock) RacingRed else Color.White
            )
        }
    }
}
