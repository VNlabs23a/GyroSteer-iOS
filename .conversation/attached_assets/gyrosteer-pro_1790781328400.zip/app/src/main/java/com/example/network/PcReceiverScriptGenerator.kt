package com.example.network

object PcReceiverScriptGenerator {

    fun generatePythonVJoyScript(port: Int = 8080): String {
        return """
# =========================================================
# 900° GYRO STEERING WHEEL - PC RECEIVER SCRIPT (Python vJoy)
# =========================================================
# Requirements on PC:
# 1. Install vJoy Driver: https://github.com/njz3/vJoy
# 2. Install python packages: pip install pyvjoy
#
# How to run:
# 1. Connect phone to PC via USB Tethering or Wi-Fi.
# 2. Find PC IP address (e.g. ipconfig -> 192.168.42.x for USB Tethering).
# 3. Enter PC IP in the Phone App Settings.
# 4. Run: python gyro_wheel_pc.py

import socket
import struct
import pyvjoy

UDP_PORT = $port
BUFFER_SIZE = 1024

print("Initialising vJoy Device 1...")
try:
    j = pyvjoy.VJoyDevice(1)
    print("✓ vJoy Device 1 ready!")
except Exception as e:
    print("X Error connecting to vJoy Device 1. Make sure vJoy is installed and configured!")
    print(e)
    j = None

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("0.0.0.0", UDP_PORT))

print(f"Server listening for 900° Gyro Wheel packets on UDP port {UDP_PORT}...")

# Button mappings to vJoy button IDs (1 to 16)
BUTTON_BIT_MAP = {
    0: 1,   # SHIFT_DOWN (Paddle L)
    1: 2,   # SHIFT_UP (Paddle R)
    2: 3,   # NITRO
    3: 4,   # HANDBRAKE
    4: 5,   # DRS
    5: 6,   # HORN
    6: 7,   # TC_PLUS
    7: 8,   # TC_MINUS
    8: 9,   # ABS_PLUS
    9: 10,  # ABS_MINUS
    10: 11, # PIT
    11: 12  # PAUSE
}

while True:
    data, addr = sock.recvfrom(BUFFER_SIZE)
    if len(data) >= 16 and data[0:2] == b'GW':
        # Unpack binary packet: magic(2B), seq(2H), steering(4f), angle(4f), mask(4i), accel(4f), brake(4f)
        seq, steering, angle, mask = struct.unpack('<Hffi', data[2:16])
        
        # Convert normalized steering [-1.0, 1.0] to vJoy axis range [0x0000, 0x8000] (0 to 32768)
        vjoy_axis_x = int((steering + 1.0) * 0.5 * 32768)
        vjoy_axis_x = max(0, min(32768, vjoy_axis_x))

        if j:
            # Set Steering Axis X
            j.set_axis(pyvjoy.HID_USAGE_X, vjoy_axis_x)

            # Process Pedals if sent
            if len(data) >= 24:
                accel, brake = struct.unpack('<ff', data[16:24])
                j.set_axis(pyvjoy.HID_USAGE_Y, int(accel * 32768))
                j.set_axis(pyvjoy.HID_USAGE_Z, int(brake * 32768))

            # Set Button states
            for bit_index, button_id in BUTTON_BIT_MAP.items():
                is_pressed = (mask & (1 << bit_index)) != 0
                j.set_button(button_id, 1 if is_pressed else 0)

        print(f"\rAngle: {angle:6.1f}° | Steering Axis X: {vjoy_axis_x:5d} | Seq: {seq}", end="")
""".trimIndent()
    }
}
