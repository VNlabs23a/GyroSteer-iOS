package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [WheelConfigEntity::class, ButtonMappingEntity::class, WheelProfileEntity::class],
    version = 3,
    exportSchema = false
)
abstract class WheelDatabase : RoomDatabase() {

    abstract fun wheelDao(): WheelDao

    companion object {
        @Volatile
        private var INSTANCE: WheelDatabase? = null

        fun getInstance(context: Context): WheelDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WheelDatabase::class.java,
                    "gyro_wheel_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
