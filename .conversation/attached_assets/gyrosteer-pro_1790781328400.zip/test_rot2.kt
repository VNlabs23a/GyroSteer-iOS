import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Surface
import kotlin.math.abs
import kotlin.math.atan2

class Test(val context: Context) : SensorEventListener {
    var accumulatedAngleDegrees: Float = 0f
    var previousRawAngle: Float = 0f
    var isFirstVector: Boolean = true

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_GAME_ROTATION_VECTOR || event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            val rotationMatrix = FloatArray(9)
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)

            // Adjust for device orientation (Landscape vs Reverse Landscape)
            val displayRotation = context.display?.rotation ?: Surface.ROTATION_0
            
            // In a phone, natural orientation is portrait.
            // R[0,1,2] is X (Right)
            // R[3,4,5] is Y (Up)
            // R[6,7,8] is Z (Out of screen)
            
            val remappedMatrix = FloatArray(9)
            when (displayRotation) {
                Surface.ROTATION_90 -> {
                    // Standard Landscape: Top of phone is left.
                    // Screen X is natural Y. Screen Y is natural -X.
                    SensorManager.remapCoordinateSystem(rotationMatrix, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X, remappedMatrix)
                }
                Surface.ROTATION_270 -> {
                    // Reverse Landscape: Top of phone is right.
                    SensorManager.remapCoordinateSystem(rotationMatrix, SensorManager.AXIS_MINUS_Y, SensorManager.AXIS_X, remappedMatrix)
                }
                else -> {
                    // Portrait or unknown, just use default (though game is forced to landscape)
                    System.arraycopy(rotationMatrix, 0, remappedMatrix, 0, 9)
                }
            }
            
            // Now, in remappedMatrix, X points RIGHT across the screen, Y points UP across the screen.
            // Z points OUT of the screen.
            // When holding like a steering wheel, Screen Y (Up) points UP in the world.
            // Screen X (Right) points RIGHT in the world.
            // Steer CCW (left turn): Screen Y tilts LEFT. Screen X tilts UP.
            // So world Z component of Screen X (remappedMatrix[2]) goes UP (positive).
            // world Z component of Screen Y (remappedMatrix[5]) goes from 1 to cos(theta).
            // Actually, atan2 of world Z components is all we need.
            
            // World Z component of Screen X axis:
            val gx = remappedMatrix[2]
            // World Z component of Screen Y axis:
            val gy = remappedMatrix[5]
            
            // When perfectly horizontal and upright: gx = 0, gy = 1.
            // Steer left (CCW) by 30 deg: gx = sin(30) = 0.5. gy = cos(30) = 0.866.
            // atan2(gx, gy) = 30 degrees!
            
            val angleRad = atan2(gx.toDouble(), gy.toDouble())
            var newAngleDeg = Math.toDegrees(angleRad).toFloat()
            
            if (isFirstVector) {
                previousRawAngle = newAngleDeg
                isFirstVector = false
            }
            
            var delta = newAngleDeg - previousRawAngle
            
            // Unwrap phase (handle +/- 180 crossing)
            if (delta > 180f) delta -= 360f
            if (delta < -180f) delta += 360f
            
            previousRawAngle = newAngleDeg
            
            // Optional rattle filter on delta to stop tiny jitters when stationary
            // Since it's drift-free, rattle filter won't cause drift!
            val dt = 0.02f // approx 50Hz
            val rate = delta / dt
            if (abs(rate) < 0.05f) { // equivalent to 0.05 rad/s threshold if converted
                // well, we can just apply a small deadzone on the delta if needed.
            }
            
            accumulatedAngleDegrees += delta
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
