package com.example.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sign

class GyroWheelSensorManager(
    private val context: Context,
    private val onAngleChanged: (rawAngleDegrees: Float, normalizedOutput: Float, isNearLock: Boolean) -> Unit
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyroSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    // Settings
    var maxAngleDegrees: Float = 900f
    var deadzonePercentage: Float = 2.0f
    var linearity: Float = 1.2f
    var smoothingFactor: Float = 0.15f
    var rattleFilter: Float = 0.05f // Gyro noise/jitter threshold in rad/s
    var autoRecenterEnabled: Boolean = false
    var hapticLockEnabled: Boolean = true
    var hapticIntensity: Float = 0.8f
    var hapticLockMarginDegrees: Float = 25f

    private var accumulatedAngleDegrees: Float = 0f
    private var zeroCalibrationOffsetDegrees: Float = 0f
    private var lastTimestampNs: Long = 0L

    private var filteredAngleDegrees: Float = 0f
    private var lastVibrationTimeMs: Long = 0L

    private var stationaryStartTimeMs: Long = 0L
    private var isListening: Boolean = false

    fun start() {
        if (isListening) return
        lastTimestampNs = 0L
        gyroSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        isListening = true
    }

    fun stop() {
        if (!isListening) return
        sensorManager.unregisterListener(this)
        isListening = false
    }

    fun recenter() {
        zeroCalibrationOffsetDegrees = accumulatedAngleDegrees
        filteredAngleDegrees = 0f
    }

    fun calibrateZeroPoint() {
        accumulatedAngleDegrees = 0f
        zeroCalibrationOffsetDegrees = 0f
        filteredAngleDegrees = 0f
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
            handleGyroscope(event)
        }
    }

    private fun handleGyroscope(event: SensorEvent) {
        val timestamp = event.timestamp
        if (lastTimestampNs != 0L) {
            val dt = (timestamp - lastTimestampNs) / 1_000_000_000.0f
            // Gyro gives rad/s around axes. 
            // Depending on holding the phone landscape, we want Z or X, but typically it's Z or we use a rotated vector.
            // If they are just holding it, Z axis is the axis pointing out of the screen. Steering left/right rotates around Z.
            val gzRadPerSec = event.values[2]

            val effectiveGz = if (abs(gzRadPerSec) < rattleFilter) 0.0f else gzRadPerSec
            val deltaDegrees = (effectiveGz * (180.0f / Math.PI.toFloat())) * dt
            
            accumulatedAngleDegrees += deltaDegrees

            if (autoRecenterEnabled) {
                val nowMs = SystemClock.elapsedRealtime()
                val currentAngle = accumulatedAngleDegrees - zeroCalibrationOffsetDegrees
                if (abs(gzRadPerSec) < 0.025f && abs(currentAngle) < 35.0f) {
                    if (stationaryStartTimeMs == 0L) {
                        stationaryStartTimeMs = nowMs
                    } else if (nowMs - stationaryStartTimeMs > 1200L) {
                        zeroCalibrationOffsetDegrees += (currentAngle * 0.08f)
                    }
                } else {
                    stationaryStartTimeMs = 0L
                }
            }
        }
        lastTimestampNs = timestamp
        processAngleUpdate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun processAngleUpdate() {
        val currentRawAngle = accumulatedAngleDegrees - zeroCalibrationOffsetDegrees
        val halfMax = maxAngleDegrees / 2.0f
        
        // Clamp to [-halfMax, +halfMax]
        val clampedRawAngle = currentRawAngle.coerceIn(-halfMax, halfMax)

        // Exponential smoothing filter
        filteredAngleDegrees = filteredAngleDegrees + (clampedRawAngle - filteredAngleDegrees) * (1.0f - smoothingFactor.coerceIn(0f, 0.95f))

        // Check if hitting lock margin for haptics
        var isNearLock = false
        if (hapticLockEnabled && abs(filteredAngleDegrees) > (halfMax - hapticLockMarginDegrees)) {
            isNearLock = true
            val now = SystemClock.elapsedRealtime()
            if (now - lastVibrationTimeMs > 40) { // rapid pulse
                triggerLockHaptic()
                lastVibrationTimeMs = now
            }
        }

        // Normalize to [-1.0, 1.0] for gaming output
        val normalizedRaw = (filteredAngleDegrees / halfMax).coerceIn(-1.0f, 1.0f)
        
        // Apply Deadzone
        val deadzoneFraction = deadzonePercentage / 100.0f
        var output = 0.0f
        
        if (abs(normalizedRaw) > deadzoneFraction) {
            val activeRange = 1.0f - deadzoneFraction
            val deadzoneAdjusted = (abs(normalizedRaw) - deadzoneFraction) / activeRange
            
            // Apply Linearity
            val linearAdjusted = deadzoneAdjusted.pow(linearity)
            output = linearAdjusted * sign(normalizedRaw)
        }

        onAngleChanged(filteredAngleDegrees, output, isNearLock)
    }

    private fun triggerLockHaptic() {
        try {
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val amplitude = (255 * hapticIntensity).toInt().coerceIn(1, 255)
                    vibrator?.vibrate(VibrationEffect.createOneShot(10, amplitude))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(10)
                }
            }
        } catch (_: Exception) {}
    }
}
