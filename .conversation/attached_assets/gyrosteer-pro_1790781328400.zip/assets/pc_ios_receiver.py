"""
iOS Safari WebApp Receiver & Windows vJoy Bridge
=================================================
Requirements:
    pip install websockets pyvjoy

How to run:
1. Connect your iPhone SE and PC to the same Wi-Fi.
2. Run this script on PC:
    python pc_ios_receiver.py
3. Note the IP address displayed (e.g. 192.168.1.50).
4. Open the webapp on iPhone Safari and enter your PC IP.
"""

import asyncio
import json
import socket
import pyvjoy

PORT = 8080

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

print("Connecting to vJoy Device 1...")
try:
    j = pyvjoy.VJoyDevice(1)
    print("✓ vJoy Device 1 ready!")
except Exception as e:
    print("X Notice: vJoy not detected or not installed. Running in telemetry monitor mode.")
    j = None

BUTTON_MAP = {
    0: 1, # Paddle Down (Shift Down)
    1: 2, # Paddle Up (Shift Up)
    2: 3, # Nitro
    3: 4  # Handbrake
}

async def handle_client(websocket):
    print(f"✓ iPhone SE Connected from {websocket.remote_address}")
    try:
        async for message in websocket:
            try:
                data = json.loads(message)
                axis_float = data.get("axis", 0.0)
                angle = data.get("angle", 0.0)
                buttons = data.get("buttons", 0)
                is_moving = data.get("isMoving", False)

                # Convert normalized [-1.0, 1.0] to vJoy [0, 32768]
                vjoy_axis = int((axis_float + 1.0) * 0.5 * 32768)
                vjoy_axis = max(0, min(32768, vjoy_axis))

                if j:
                    j.set_axis(pyvjoy.HID_USAGE_X, vjoy_axis)
                    for bit, vjoy_btn in BUTTON_MAP.items():
                        pressed = (buttons & (1 << bit)) != 0
                        j.set_button(vjoy_btn, 1 if pressed else 0)

                motion_str = "TURNING" if is_moving else "RESTING"
                print(f"\rAngle: {angle:+6.1f}° | Axis X: {vjoy_axis:5d} | State: {motion_str}", end="")
            except Exception as e:
                pass
    except Exception:
        print("\n iPhone disconnected.")

async def main():
    ip = get_local_ip()
    print("=" * 60)
    print(f" iPhone SE Gyro Steering Bridge Running!")
    print(f" PC Server Address: ws://{ip}:{PORT}")
    print("=" * 60)
    import websockets
    async with websockets.serve(handle_client, "0.0.0.0", PORT):
        await asyncio.Future()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nServer stopped.")
